"""Full indexed surfaces, smooth lighting and depth buffering using Qt's own GL."""
import ctypes
import logging
import numpy as np
from PyQt5 import QtCore as C, QtGui as G, QtWidgets as W
from software_view import SoftwareMeshView

def configure_graphics():
    fmt=G.QSurfaceFormat();fmt.setVersion(2,1);fmt.setDepthBufferSize(24);fmt.setSamples(4)
    G.QSurfaceFormat.setDefaultFormat(fmt)

VERTEX='''
attribute vec3 position; attribute vec3 normal;
uniform mat4 transform; uniform mat4 view; uniform vec3 modelScale;
varying vec3 worldPosition; varying vec3 eyeNormal;
void main(){worldPosition=position*modelScale;
eyeNormal=(view*vec4(normal/modelScale,0.)).xyz;
gl_Position=transform*vec4(worldPosition,1.);}
'''
FRAGMENT='''
#ifdef GL_ES
precision mediump float;
#endif
varying vec3 worldPosition; varying vec3 eyeNormal;
uniform vec3 planeNormal; uniform vec3 planeOrigin; uniform vec3 baseColor;
uniform bool showPlane; uniform bool flat;
void main(){
if(flat){gl_FragColor=vec4(baseColor,1.);return;}
vec3 n=normalize(eyeNormal); if(!gl_FrontFacing)n=-n;
vec3 light=normalize(vec3(-.35,.5,.85));
float diffuse=max(dot(n,light),0.);
float spec=pow(max(dot(n,normalize(light+vec3(0.,0.,1.))),0.),36.)*.18;
vec3 color=baseColor;
if(showPlane && dot(worldPosition-planeOrigin,planeNormal)<-.0001)
color=mix(color,vec3(.47,.52,.59),.6);
gl_FragColor=vec4(color*(.38+.62*diffuse)+vec3(spec),1.);
}
'''

class MeshView(W.QOpenGLWidget):
    picked=C.pyqtSignal(object)
    basis=SoftwareMeshView.basis
    camera_position=SoftwareMeshView.camera_position
    scale_factor=SoftwareMeshView.scale_factor
    project=SoftwareMeshView.project
    fit=SoftwareMeshView.fit
    preset=SoftwareMeshView.preset
    pick_surface=SoftwareMeshView.pick_surface
    disable_picking=SoftwareMeshView.disable_picking
    enable_surface_point_picking=SoftwareMeshView.enable_surface_point_picking
    mousePressEvent=SoftwareMeshView.mousePressEvent
    mouseMoveEvent=SoftwareMeshView.mouseMoveEvent
    mouseReleaseEvent=SoftwareMeshView.mouseReleaseEvent
    mouseDoubleClickEvent=SoftwareMeshView.mouseDoubleClickEvent
    wheelEvent=SoftwareMeshView.wheelEvent
    reset_camera=SoftwareMeshView.reset_camera
    add_axes=SoftwareMeshView.add_axes

    def __init__(self,parent=None):
        super().__init__(parent);self.setMinimumSize(360,320)
        self.setMouseTracking(True);self.setFocusPolicy(C.Qt.StrongFocus)
        self.yaw,self.pitch=-.75,.5;self.zoom=1.;self.pan=np.zeros(2);self.center=np.zeros(3);self.radius=60.
        self.mesh=None;self.lines=[];self._pick=None;self._last=None;self._moved=False;self._screen=None
        self._plane=None;self._origin=np.zeros(3);self._vertices=None;self._indices=None;self._dirty=False
        self._source_mesh=None;self._scale=np.ones(3)
        self._program=None;self._vbo=None;self._ebo=None;self._line_vbo=None;self._gl={};self._error=None;self._count=0

    @property
    def displayed_face_count(self):return self._count//3

    @property
    def displayed_vertices(self):return self._vertices[:,:3]*self._scale

    def set_mesh(self,mesh,normal=None,origin=None,ribs=None,fit=False,source_mesh=None,scale=None):
        if mesh is None:self.clear();return
        source=mesh if source_mesh is None else source_mesh
        changed=source is not self._source_mesh;self.mesh=mesh;self._source_mesh=source
        self._scale=np.ones(3) if scale is None else np.asarray(scale,dtype=float)
        if changed:
            self._vertices=np.ascontiguousarray(np.column_stack((source.vertices,source.vertex_normals)),dtype=np.float32)
            self._indices=np.ascontiguousarray(source.faces,dtype=np.uint32).reshape(-1)
            self._count=int(self._indices.size);self._dirty=True
        self._plane=None if normal is None else np.asarray(normal,dtype=float)
        self._origin=np.zeros(3) if origin is None else np.asarray(origin,dtype=float);self.lines=[]
        if normal is not None:
            n=self._plane;o=self._origin;axis=np.eye(3)[int(np.argmin(np.abs(n)))]
            u=np.cross(n,axis);u/=np.linalg.norm(u);v=np.cross(n,u);s=float(mesh.extents.max())*.65
            corners=np.array([o+s*(a*u+b*v) for a,b in ((-1,-1),(1,-1),(1,1),(-1,1),(-1,-1))])
            self.lines.append((corners,'#e6b36d',1.5));self.lines.append((np.array([o,o+n*s*.55]),'#f18b7c',2.))
            if ribs is not None:
                ru,rv=ribs
                self.lines.append((np.array([o,o+ru*s*.55]),'#71d6b0',4.))
                self.lines.append((np.array([o-rv*s,o+rv*s]),'#537477',1.))
                projections=(mesh.vertices-o)@ru
                for position in np.linspace(float(projections.min()),float(projections.max()),7)[1:-1]:
                    center=o+ru*position
                    self.lines.append((np.array([center-rv*s*.55,center+rv*s*.55,center+rv*s*.55+n*s*.8,center-rv*s*.55+n*s*.8,center-rv*s*.55]),'#85a8df',0.8))

        if fit:self.fit()
        self.update()

    def set_assembly(self,mesh,fit=True):self.set_mesh(mesh,fit=fit)
    def clear(self):
        self.mesh=None;self._source_mesh=None;self.lines=[];self._vertices=None;self._indices=None;self._count=0;self._dirty=True;self.update()

    def _function(self,name,result,*args):
        address=self.context().getProcAddress(name.encode('ascii'))
        if not address:raise RuntimeError('Missing OpenGL function: '+name)
        return getattr(ctypes,'WINFUNCTYPE',ctypes.CFUNCTYPE)(result,*args)(int(address))

    def initializeGL(self):
        try:
            for name,result,args in [
                ('glClearColor',None,(ctypes.c_float,)*4),('glClear',None,(ctypes.c_uint,)),
                ('glEnable',None,(ctypes.c_uint,)),('glDisable',None,(ctypes.c_uint,)),
                ('glDrawElements',None,(ctypes.c_uint,ctypes.c_int,ctypes.c_uint,ctypes.c_void_p)),
                ('glDrawArrays',None,(ctypes.c_uint,ctypes.c_int,ctypes.c_int)),
                ('glViewport',None,(ctypes.c_int,)*4),('glLineWidth',None,(ctypes.c_float,))]:
                self._gl[name]=self._function(name,result,*args)
            self._program=G.QOpenGLShaderProgram(self)
            for kind,source in ((G.QOpenGLShader.Vertex,VERTEX),(G.QOpenGLShader.Fragment,FRAGMENT)):
                if not self._program.addShaderFromSourceCode(kind,source):raise RuntimeError(self._program.log())
            if not self._program.link():raise RuntimeError(self._program.log())
            self._vbo=G.QOpenGLBuffer(G.QOpenGLBuffer.VertexBuffer);self._vbo.create()
            self._ebo=G.QOpenGLBuffer(G.QOpenGLBuffer.IndexBuffer);self._ebo.create()
            self._line_vbo=G.QOpenGLBuffer(G.QOpenGLBuffer.VertexBuffer);self._line_vbo.create()
            self._dirty=True;self.context().aboutToBeDestroyed.connect(self._cleanup)
        except Exception as exc:self._error=str(exc);logging.exception('OpenGL initialization failed')

    def _cleanup(self):
        if self._vbo is None:return
        self.makeCurrent()
        if self._program is not None:
            self._program.release();self._program.removeAllShaders();self._program.deleteLater();self._program=None
        for buffer in (self._vbo,self._ebo,self._line_vbo):
            if buffer is not None:buffer.destroy()
        self._vbo=self._ebo=self._line_vbo=None
        self.doneCurrent()

    def closeEvent(self,event):
        self._cleanup()
        super().closeEvent(event)

    def resizeGL(self,w,h):pass

    def _matrices(self):
        b=self.basis();view=np.eye(4);view[:3,:3]=b;view[:3,3]=-b@self.center
        s=self.scale_factor();projection=np.eye(4)
        projection[0,0]=2*s/max(1,self.width());projection[1,1]=2*s/max(1,self.height())
        projection[0,3]=2*self.pan[0]/max(1,self.width());projection[1,3]=-2*self.pan[1]/max(1,self.height())
        depth=max(self.radius*8,float(self.mesh.extents.max())*4 if self.mesh is not None else 1)
        projection[2,2]=-1/depth
        return G.QMatrix4x4(*(projection@view).ravel().tolist()),G.QMatrix4x4(*view.ravel().tolist())

    def paintGL(self):
        gl=self._gl
        if self._error or not self._program:self._overlay(self._error or 'OpenGL unavailable');return
        gl['glViewport'](0,0,int(self.width()*self.devicePixelRatioF()),int(self.height()*self.devicePixelRatioF()))
        gl['glClearColor'](.067,.098,.137,1.);gl['glClear'](0x4000|0x0100)
        gl['glEnable'](0x0B71);gl['glDisable'](0x0BE2)
        if self.mesh is not None and self._count:
            if self._dirty:
                self._vbo.bind();self._vbo.allocate(self._vertices.tobytes(),self._vertices.nbytes);self._vbo.release()
                self._ebo.bind();self._ebo.allocate(self._indices.tobytes(),self._indices.nbytes);self._ebo.release();self._dirty=False
            p=self._program;p.bind();matrix,view=self._matrices()
            p.setUniformValue('transform',matrix);p.setUniformValue('view',view)
            p.setUniformValue('baseColor',G.QVector3D(.40,.69,.85));p.setUniformValue('flat',False)
            p.setUniformValue('modelScale',G.QVector3D(*self._scale))
            p.setUniformValue('showPlane',self._plane is not None)
            p.setUniformValue('planeNormal',G.QVector3D(*(self._plane if self._plane is not None else np.zeros(3))))
            p.setUniformValue('planeOrigin',G.QVector3D(*self._origin))
            self._vbo.bind();self._ebo.bind()
            p.enableAttributeArray('position');p.setAttributeBuffer('position',0x1406,0,3,24)
            p.enableAttributeArray('normal');p.setAttributeBuffer('normal',0x1406,12,3,24)
            gl['glDrawElements'](0x0004,self._count,0x1405,None)
            self._ebo.release();self._vbo.release();p.setUniformValue('flat',True);p.disableAttributeArray('normal')
            p.setUniformValue('modelScale',G.QVector3D(1.,1.,1.))
            for points,color,width in self.lines:
                a=np.ascontiguousarray(points,dtype=np.float32);self._line_vbo.bind();self._line_vbo.allocate(a.tobytes(),a.nbytes)
                p.setAttributeBuffer('position',0x1406,0,3,12)
                q=G.QColor(color);p.setUniformValue('baseColor',G.QVector3D(q.redF(),q.greenF(),q.blueF()))
                gl['glLineWidth'](width);gl['glDrawArrays'](0x0003,0,len(points));self._line_vbo.release()
            p.disableAttributeArray('position');p.release()
        gl['glDisable'](0x0B71);self._overlay()

    def _overlay(self,error=None):
        p=G.QPainter(self);p.setRenderHint(G.QPainter.Antialiasing)
        if self.mesh is None or error:
            p.setPen(G.QColor('#64d7bb'));f=p.font();f.setPointSize(28);f.setBold(True);p.setFont(f)
            p.drawText(self.rect().adjusted(0,-30,0,-30),C.Qt.AlignCenter,'ELEVEN')
            f.setPointSize(11);f.setBold(False);p.setFont(f);p.setPen(G.QColor('#9badc0'))
            text='خطای نمایش؛ برنامه را با RUN_SOFTWARE_GRAPHICS.bat اجرا کنید.' if error else 'برای شروع، یک مدل سه‌بعدی باز کنید'
            p.drawText(self.rect().adjusted(40,35,-40,35),C.Qt.AlignCenter|C.Qt.TextWordWrap,text)
        if self.mesh is not None:
            base=np.array([52,self.height()-48])
            for i,(color,label) in enumerate((('#ff877a','X'),('#71d6ab','Y'),('#76adf7','Z'))):
                d=self.basis()[:2,i]*np.array([1,-1])*30
                p.setPen(G.QPen(G.QColor(color),2));p.drawLine(C.QPointF(*base),C.QPointF(*(base+d)));p.drawText(C.QPointF(*(base+d*1.25)),label)
        p.end()
