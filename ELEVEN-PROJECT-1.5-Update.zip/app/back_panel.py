"""Assembly marks in the actual rib frame, in millimetres."""
import math
import ezdxf
from shapely.geometry import LineString
from shapely.ops import unary_union
from ezdxf.enums import TextEntityAlignment


def panel_document(slabs, size=500.0):
    if not slabs:
        raise ValueError('قطعه‌ای برای مونتاژ وجود ندارد.')
    records = []
    for i, (z0, z1, polygons, _) in enumerate(slabs, 1):
        shape = unary_union(polygons)
        # Only a contour that reaches the rear plane is mountable. Allow the
        # small rounding offset introduced by section repair, not floating islands.
        touching = [p for p in getattr(shape, 'geoms', [shape]) if p.bounds[1] <= 0.02 and p.bounds[3] >= 0]
        if not touching:
            raise ValueError(f'قطعهٔ {i} به صفحهٔ پشت نمی‌رسد؛ اتصال به پشت را فعال کنید.')
        base = min(p.bounds[1] for p in touching)
        union = unary_union(touching)
        x0, _, x1, _ = union.bounds
        contact = union.intersection(LineString([(x0-1, max(0.0, base)+0.001), (x1+1, max(0.0, base)+0.001)]))
        if contact.is_empty or contact.bounds[2]-contact.bounds[0] <= 1e-6:
            raise ValueError(f'تماس قطعهٔ {i} با پنل قابل تشخیص نیست.')
        records.append((i, float(z0), float(z1), contact.bounds[0], contact.bounds[2]))
    lo = min(r[1] for r in records); hi = max(r[2] for r in records)
    bottom = min(r[3] for r in records); top = max(r[4] for r in records)
    if not all(math.isfinite(v) for r in records for v in r) or any(r[2] <= r[1] for r in records):
        raise ValueError('مختصات قطعات معتبر نیست.')
    if hi-lo > size or top-bottom > size:
        raise ValueError(f'قطعات بدون تغییر مقیاس در پنل {size:g}×{size:g} جا نمی‌شوند. حداقل ابعاد: {hi-lo:.2f} × {top-bottom:.2f} میلی‌متر.')
    dx = (size-lo-hi)/2; dy = (size-bottom-top)/2
    doc = ezdxf.new('R2010'); doc.units = 4; doc.header['$MEASUREMENT'] = 1
    for name, color in [('PANEL_CUT',7), ('MOUNT_MARK_ENGRAVE',3), ('PART_NUMBERS_ENGRAVE',1), ('NOTES_NO_CUT',5)]:
        doc.layers.new(name, dxfattribs={'color':color})
    m = doc.modelspace()
    m.add_lwpolyline([(0,0),(size,0),(size,size),(0,size)], close=True, dxfattribs={'layer':'PANEL_CUT'})
    for number, z0, z1, start, end in records:
        entities = []
        for j, y in enumerate([start+dy,end+dy]):
            entities.append(m.add_line((z0+dx,y),(z1+dx,y), dxfattribs={'layer':'MOUNT_MARK_ENGRAVE','color':3}))
            text = m.add_text(str(number), dxfattribs={'height':2,'layer':'PART_NUMBERS_ENGRAVE','color':1})
            text.set_placement(((z0+z1)/2+dx, max(3,min(size-3,y+(-2 if j==0 else 2)))), align=TextEntityAlignment.MIDDLE_CENTER)
            entities.append(text)
        doc.groups.new(f'PART_{number:03d}_MOUNT').set_data(entities)
    notes = [f'{size:g} x {size:g} mm | {len(records)} PARTS | SCALE 1:1',
             'ACTUAL RIB POSITIONS AND THICKNESSES. NO ASSUMED GAP.',
             'BLACK: CUT PANEL. GREEN AND RED: ENGRAVE ONLY.',
             'PANEL AXES: HORIZONTAL u; VERTICAL v. PART NUMBERS MATCH PART DXF.']
    for i, note in enumerate(notes):
        m.add_text(note, dxfattribs={'height':4,'layer':'NOTES_NO_CUT','color':5}).set_placement((0,-12-i*8))
    return doc, min((size-hi+lo)/2, (size-top+bottom)/2)
