"""Shared camera, projection and full-resolution surface-picking controls."""
import math
import numpy as np
from PyQt5 import QtCore as C, QtGui as G, QtWidgets as W


class SoftwareMeshView(W.QWidget):
    picked = C.pyqtSignal(object)


    def basis(self):
        cy, sy = math.cos(self.yaw), math.sin(self.yaw)
        cp, sp = math.cos(self.pitch), math.sin(self.pitch)
        right = np.array([cy, sy, 0.0])
        up = np.array([-sy * sp, cy * sp, cp])
        toward = np.cross(right, up)
        return np.array([right, up, toward])

    @property
    def camera_position(self):
        return (self.center + self.basis()[2] * self.radius * 3,
                self.center.copy(), self.basis()[1])

    def scale_factor(self):
        return min(self.width(), self.height()) * 0.40 / max(self.radius, 1e-9) * self.zoom

    def project(self, points):
        q = (np.asarray(points) - self.center) @ self.basis().T
        xy = q[..., :2] * np.array([1, -1]) * self.scale_factor()
        xy += np.array([self.width() / 2, self.height() / 2]) + self.pan
        return xy, q[..., 2]

    def fit(self):
        if self.mesh is not None:
            self.center = self.mesh.bounds.mean(axis=0)
            self.radius = float(max(self.mesh.extents.max(), 1e-6)) * 0.65
        self.zoom = 1.0
        self.pan[:] = 0
        self._screen = None
        self.update()

    def preset(self, name):
        self.yaw, self.pitch = {'iso': (-0.75, 0.5), 'front': (0, 0),
                                'top': (0, math.pi / 2), 'side': (math.pi / 2, 0)}[name]
        self._screen = None
        self.update()





    def add_axes(self):
        self.update()

    def reset_camera(self):
        self.fit()

    def disable_picking(self):
        self._pick = None
        self.unsetCursor()

    def enable_surface_point_picking(self, callback, **kwargs):
        self._pick = callback
        self.setCursor(C.Qt.CrossCursor)

    def pick_surface(self, pos):
        if self.mesh is None:
            return None
        b = self.basis()
        xy = (np.array([pos.x(),pos.y()]) - np.array([self.width()/2,self.height()/2])-self.pan) / self.scale_factor()
        start = self.center+b[0]*xy[0]-b[1]*xy[1]+b[2]*self.radius*4
        direction = -b[2]
        # Orthographic ray/triangle test against the ORIGINAL full-resolution mesh.
        ts = self.mesh.triangles
        e1, e2 = ts[:,1]-ts[:,0], ts[:,2]-ts[:,0]
        h = np.cross(np.broadcast_to(direction,e2.shape),e2)
        det = np.einsum('ij,ij->i',e1,h)
        ok = np.abs(det)>1e-12
        f = np.zeros_like(det); f[ok] = 1/det[ok]
        s = start-ts[:,0]
        u = f*np.einsum('ij,ij->i',s,h)
        q = np.cross(s,e1)
        v = f*(q@direction)
        t = f*np.einsum('ij,ij->i',e2,q)
        ok &= (u>=0)&(v>=0)&(u+v<=1)&(t>=0)
        if not ok.any():
            return None
        return start+direction*float(t[np.flatnonzero(ok)[np.argmin(t[ok])]])



    def mousePressEvent(self,event):
        self._last=event.pos(); self._moved=False

    def mouseMoveEvent(self,event):
        if self._last is None or not event.buttons(): return
        d=event.pos()-self._last
        self._moved |= d.manhattanLength()>2
        if event.buttons() & C.Qt.LeftButton and not event.modifiers() & C.Qt.ShiftModifier:
            self.yaw += d.x()*0.008
            self.pitch = max(-math.pi/2,min(math.pi/2,self.pitch+d.y()*0.008))
        else:
            self.pan += [d.x(),d.y()]
        self._last=event.pos(); self._screen=None; self.update()

    def mouseReleaseEvent(self,event):
        if self._pick and not self._moved and event.button()==C.Qt.LeftButton:
            pt=self.pick_surface(event.pos())
            if pt is not None: self._pick(pt)
        self._last=None

    def wheelEvent(self,event):
        self.zoom = max(0.05,min(50,self.zoom*1.15**(event.angleDelta().y()/120)))
        self._screen=None; self.update()

    def mouseDoubleClickEvent(self,event):
        self.fit()
