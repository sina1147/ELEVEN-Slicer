@echo off
setlocal
cd /d "%~dp0"
set "QT_OPENGL=software"
"%~dp0runtime\pythonw.exe" -I "%~dp0bootstrap.py"
if errorlevel 1 (
 echo ELEVEN could not start. Run RUN_DIAGNOSTIC.bat for details.
 pause
)
