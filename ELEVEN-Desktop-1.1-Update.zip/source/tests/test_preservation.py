"""Compare the uploaded engine with the desktop version at the geometry/DXF boundary."""
import ast
import importlib.util
import json
import os
import sys
import tempfile
import types
import unittest
from pathlib import Path

if sys.platform!='win32' and not os.environ.get('DISPLAY'):
    os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
ROOT=Path(__file__).resolve().parents[1]
APP_ROOT=ROOT if (ROOT/'app').exists() else ROOT.parent
sys.path.insert(0,str(APP_ROOT/'app'))
import numpy as np
import trimesh
import ezdxf
from PyQt5 import QtWidgets as W, QtCore as C
from main import Desktop
from viewer import configure_graphics


def reference_module():
    # Original numerical methods do not require a VTK renderer for these meshes.
    # Supply just the full-resolution data adapter used by original analysis_mesh.
    # This deliberately does not claim to test the original VTK rendering.
    saved={name:sys.modules.get(name) for name in ('pyvista','pyvistaqt')}
    sys.modules['pyvista']=types.ModuleType('pyvista')
    module=types.ModuleType('pyvistaqt'); module.QtInteractor=None; sys.modules['pyvistaqt']=module
    try:
        spec=importlib.util.spec_from_file_location('uploaded_reference',ROOT/'original/mesh2dxf.py')
        ref=importlib.util.module_from_spec(spec); spec.loader.exec_module(ref)
        return ref
    finally:
        for name,value in saved.items():
            if value is None:sys.modules.pop(name,None)
            else:sys.modules[name]=value


class Preservation(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        configure_graphics()
        cls.app=W.QApplication.instance() or W.QApplication([])
        cls.reference=reference_module()

    def setUp(self):
        self.w=Desktop()
        self.w.show_error=lambda title,exc:(_ for _ in ()).throw(exc)

    def tearDown(self):
        self.w.close(); self.w.deleteLater(); self.app.sendPostedEvents(None,C.QEvent.DeferredDelete); self.app.processEvents()

    def set_mesh(self,mesh):
        with tempfile.TemporaryDirectory() as td:
            path=Path(td)/'test.stl'; mesh.export(path)
            self.w.load_model(str(path))

    def reference_state(self):
        cls=self.reference.App; r=cls.__new__(cls); W.QMainWindow.__init__(r)
        for name in ('sx','sy','sz','ox','oy','oz','ang_a','ang_b','thick','gap','merge_d','minpct','tol','maxslab','rib_t','rib_ang','rib_web','back_off','rib_mode','rib_axis','quality','back_face','flip','holes','rib_bridge','snap'):
            setattr(r,name,getattr(self.w,name))
        r.mesh=self.w.mesh.copy(); r.cam_vec=self.w.cam_vec; r._frame=None
        r.pm_disp=types.SimpleNamespace(is_all_triangles=True,points=r.mesh.vertices,
            faces=np.column_stack([np.full(len(r.mesh.faces),3),r.mesh.faces]).reshape(-1))
        return r

    def assert_slabs_equal(self,a,b):
        self.assertEqual(len(a),len(b))
        for aa,bb in zip(a,b):
            np.testing.assert_allclose([aa[0],aa[1],aa[3]],[bb[0],bb[1],bb[3]],atol=1e-9)
            self.assertEqual(len(aa[2]),len(bb[2]))
            for x,y in zip(aa[2],bb[2]):self.assertLess(x.symmetric_difference(y).area,1e-7)

    def test_geometry_methods_unchanged(self):
        def methods(path):
            tree=ast.parse(path.read_text(encoding='utf-8')); cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='App')
            return {n.name:ast.dump(n,include_attributes=False) for n in cls.body if isinstance(n,ast.FunctionDef)}
        a=methods(ROOT/'original/mesh2dxf.py'); b=methods(APP_ROOT/'app/engine.py')
        names=('normal','origin','rib_frame','layer_polys','compute_layers','clean_layer','merge_layers','fill_section','plan_ribs','rib_parts','sig','build_slabs','arrange','label','to3d','export_dxf')
        for name in names:self.assertEqual(a[name],b[name],name)

    def test_rib_quality_axis_face_matrix(self):
        self.set_mesh(trimesh.creation.icosphere(subdivisions=1,radius=20))
        cases=[('ymax','x'),('ymin','z'),('xmax','y'),('xmin','x'),('zmax','x'),('zmin','y')]
        counts=[]
        for face,axis in cases:
            for level in (1,2,3,4):
                with self.subTest(face=face,axis=axis,quality=level):
                    self.w.back_face.setCurrentIndex(self.w.back_face.findData(face))
                    self.w.rib_axis.btns[axis].setChecked(True); self.w.plane_changed()
                    self.w.quality.setCurrentIndex(self.w.quality.findData(level))
                    r=self.reference_state()
                    a=self.w.rib_parts(); b=r.rib_parts()
                    self.assertGreater(len(a),0)
                    self.assert_slabs_equal(a,b); self.assertEqual(self.w.rib_info,r.rib_info)
                    counts.append(len(a)); r.close(); r.deleteLater()
        print('Compared 24 rib cases; part counts:',counts)

    def test_layered_holes_merge_and_export(self):
        self.set_mesh(trimesh.creation.annulus(r_min=8,r_max=20,height=35,sections=24))
        self.w.back_face.setCurrentIndex(self.w.back_face.findData('zmin'))
        self.w.rib_mode.setChecked(False)
        for holes in (False,True):
            for tolerance in (0,0.5):
                with self.subTest(holes=holes,tolerance=tolerance):
                    self.w.holes.setChecked(holes); self.w.tol.setValue(tolerance)
                    r=self.reference_state()
                    la=[(h,self.w.clean_layer(gs)) for h,gs in self.w.compute_layers()]
                    lb=[(h,r.clean_layer(gs)) for h,gs in r.compute_layers()]
                    a=self.w.merge_layers(la,self.w.thick.value()); b=r.merge_layers(lb,r.thick.value())
                    self.assert_slabs_equal(a,b)
                    self.assertGreater(len(a),0)
                    # Preserve the source behavior, including its contour-buffer
                    # edge cases; verify explicit hole retention separately below.
                    self.assertEqual([len(g.interiors) for sl in a for g in sl[2]],
                                     [len(g.interiors) for sl in b for g in sl[2]])
                    self.assertEqual(self.w.arrange(a),r.arrange(b))
                    for i,sl in enumerate(a):self.assertEqual(self.w.label(i,sl),r.label(i,b[i]))
                    r.close(); r.deleteLater()
        with tempfile.TemporaryDirectory() as td:
            path=Path(td)/'output.dxf'
            old=W.QFileDialog.getSaveFileName
            W.QFileDialog.getSaveFileName=lambda *a,**kw:(str(path),'DXF')
            try:self.w.export_dxf()
            finally:W.QFileDialog.getSaveFileName=old
            doc=ezdxf.readfile(path); entities=list(doc.modelspace())
            cuts=[e for e in entities if e.dxftype()=='LWPOLYLINE']
            self.assertGreater(len(cuts),0); self.assertTrue(all(e.closed and e.dxf.layer=='CUT' for e in cuts))
            self.assertTrue(any(e.dxftype()=='CIRCLE' and e.dxf.layer=='REG' for e in entities))
            self.assertTrue(any(e.dxftype()=='TEXT' and e.dxf.layer=='LABEL' for e in entities))

    def test_explicit_hole_cleanup_and_dxf(self):
        from shapely.geometry import Polygon
        self.set_mesh(trimesh.creation.box(extents=[40,40,40]))
        polygon=Polygon([(0,0),(40,0),(40,40),(0,40)],holes=[[(10,10),(10,30),(30,30),(30,10)]])
        for keep in (False,True):
            self.w.holes.setChecked(keep); r=self.reference_state()
            a=self.w.clean_layer([polygon]); b=r.clean_layer([polygon])
            self.assertEqual(len(a[0].interiors),1 if keep else 0)
            self.assertLess(a[0].symmetric_difference(b[0]).area,1e-7)
            r.close(); r.deleteLater()
        slabs=[(0,2.6,[polygon],1)]
        self.w._cache=(self.w.sig(),(slabs,1,1,1))
        with tempfile.TemporaryDirectory() as td:
            target=Path(td)/'holes.dxf'; old=W.QFileDialog.getSaveFileName
            W.QFileDialog.getSaveFileName=lambda *a,**kw:(str(target),'DXF')
            try:self.w.export_dxf()
            finally:W.QFileDialog.getSaveFileName=old
            cuts=list(ezdxf.readfile(target).modelspace().query('LWPOLYLINE'))
            self.assertEqual(len(cuts),2); self.assertTrue(all(e.closed for e in cuts))

    def test_custom_camera_bridge_and_scaling(self):
        self.set_mesh(trimesh.creation.box(extents=[30,20,40]))
        self.w.sx.setValue(60)
        np.testing.assert_allclose(self.w.mesh.extents,[60,40,80])
        self.w.from_camera(); self.assertEqual(self.w.back_face.currentData(),'camera')
        for bridge in (False,True):
            self.w.rib_bridge.setChecked(bridge)
            self.w.back_face.setCurrentIndex(self.w.back_face.findData('custom'))
            self.w.ang_a.setValue(5); self.w.ang_b.setValue(20); self.w.oy.setValue(-15)
            r=self.reference_state(); self.assert_slabs_equal(self.w.rib_parts(),r.rib_parts())
            r.close(); r.deleteLater()

    def test_settings_roundtrip_and_reject_bad_file(self):
        self.set_mesh(trimesh.creation.box(extents=[20,30,40]))
        self.w.back_face.setCurrentIndex(self.w.back_face.findData('custom')); self.w.ox.setValue(3)
        data=self.w.settings_data(); self.w.sx.setValue(80); self.w.apply_settings(data)
        self.assertEqual(data,self.w.settings_data())
        bad=data.copy(); bad['sx']=-1
        before=self.w.settings_data()
        with self.assertRaises(ValueError):self.w.apply_settings(bad)
        self.assertEqual(before,self.w.settings_data())

    def test_viewer_picking_and_all_previews(self):
        self.set_mesh(trimesh.creation.box(extents=[20,30,40])); self.w.plotter.fit()
        p=self.w.plotter.rect().center(); hit=self.w.plotter.pick_surface(p)
        self.assertIsNotNone(hit)
        self.assertTrue(any(abs(abs(hit[i])-self.w.mesh.extents[i]/2)<1e-6 for i in range(3)))
        self.w.preview(); self.assertGreater(len(self.w.view2d.scene().items()),0)
        self.assertIsNotNone(self.w.plotter2.mesh)
        for tab in range(3):
            self.w.tabs.setCurrentIndex(tab); self.w.show(); self.app.processEvents()
            self.assertFalse(self.w.grab().isNull())


if __name__=='__main__':unittest.main(verbosity=2)
