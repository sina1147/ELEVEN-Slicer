"""ELEVEN Desktop — native, offline UI over the uploaded Mesh → DXF engine."""
import json
import logging
import os
import sys
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import trimesh
from shapely import constrained_delaunay_triangles
from PyQt5 import QtCore as C, QtGui as G, QtWidgets as W

from engine import App as Engine, View2D, AxisPick, FACES, dspin
from viewer import MeshView

VERSION = '1.0'
STYLE = '''
QMainWindow, QWidget { background:#151e2a; color:#dbe5ef; font-family:"Segoe UI", Tahoma; font-size:12px; }
QLabel { background:transparent; }
QFrame#header { background:#1b2635; border-bottom:1px solid #2b394a; }
QLabel#brand { color:#6cddc3; font-size:21px; font-weight:700; letter-spacing:3px; }
QLabel#subtitle { color:#8799ad; font-size:11px; }
QLabel#filename { font-weight:600; font-size:13px; }
QLabel#hint { color:#8d9db0; font-size:11px; }
QLabel#sectionTitle { color:#eef5fb; font-size:17px; font-weight:600; }
QPushButton, QToolButton { background:#243247; border:1px solid #35465b; border-radius:7px; padding:8px 13px; }
QPushButton:hover, QToolButton:hover { background:#30425a; border-color:#5b7895; }
QPushButton:pressed, QToolButton:checked { background:#17594f; border-color:#60d4b6; color:#a7f4dc; }
QPushButton:disabled { background:#1b2532; color:#56687c; border-color:#273647; }
QPushButton#primary { background:#59d5b4; color:#102b29; border:0; font-weight:700; padding:11px 20px; }
QPushButton#primary:hover { background:#80e6ca; }
QPushButton#primary:disabled { background:#264d49; color:#648f85; }
QScrollArea { border:0; background:#182330; }
QWidget#settingsPanel { background:#182330; }
QGroupBox { background:#1c2938; border:1px solid #304053; border-radius:10px; margin-top:18px; padding:16px 12px 12px; font-weight:600; }
QGroupBox::title { subcontrol-origin:margin; subcontrol-position:top right; padding:0 8px; color:#98e1d0; }
QGroupBox QWidget { background:transparent; }
QDoubleSpinBox, QSpinBox, QComboBox { background:#111d2a; border:1px solid #35495e; border-radius:5px; padding:7px 6px; min-height:18px; selection-background-color:#2c8271; }
QDoubleSpinBox:focus, QComboBox:focus { border-color:#64d8b8; }
QComboBox QAbstractItemView { background:#1c2938; selection-background-color:#2b5e56; padding:5px; }
QCheckBox, QRadioButton { spacing:7px; padding:4px 0; }
QCheckBox::indicator, QRadioButton::indicator { width:15px; height:15px; }
QTabWidget::pane { border:1px solid #2b3b4d; border-radius:8px; }
QTabBar::tab { background:#1b2838; padding:12px 20px; color:#9cacc0; border-bottom:2px solid transparent; }
QTabBar::tab:selected { color:#89e5cd; background:#213444; border-bottom:2px solid #60d4b6; }
QProgressBar { background:#152231; border:0; height:5px; border-radius:2px; color:transparent; }
QProgressBar::chunk { background:#62d8b8; border-radius:2px; }
QStatusBar { background:#111a25; border-top:1px solid #2a3849; color:#8da2b8; }
QScrollBar:vertical { background:#172330; width:8px; margin:0; }
QScrollBar::handle:vertical { background:#3c5066; border-radius:4px; min-height:32px; }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height:0; }
QMenuBar { background:#111a25; padding:3px; }
QMenuBar::item:selected, QMenu::item:selected { background:#2c4b5a; }
QMenu { background:#1e2b3c; border:1px solid #40556c; padding:6px; }
QMenu::item { padding:7px 28px; }
QToolTip { background:#213448; color:#e4f0fa; border:1px solid #55778e; padding:7px; }
QSplitter::handle { background:#28384a; width:1px; }
'''


class Desktop(Engine):
    def __init__(self):
        # The inherited geometry methods are retained verbatim from the upload.
        W.QMainWindow.__init__(self)
        self.setWindowTitle('ELEVEN • Mesh to DXF')
        self.setWindowIcon(G.QIcon(str(Path(__file__).with_name('eleven.ico'))))
        self.setMinimumSize(1080,720)
        self.resize(1440,920)
        self.setAcceptDrops(True)
        self.base=self.mesh=self.orig=None
        self.pm_disp=None
        self._cache=self._frame=None
        self._lock_busy=False
        self.cam_vec=None
        self._busy=False
        self.model_path=None
        self._fresh=True
        self._mode_buttons=[]
        self._build_ui()
        self._build_menu()
        self.setStyleSheet(STYLE)
        self.plane_changed()
        self._set_ready(False)

    def _build_ui(self):
        root=W.QWidget(); self.setCentralWidget(root)
        outer=W.QVBoxLayout(root); outer.setContentsMargins(0,0,0,0); outer.setSpacing(0)
        header=W.QFrame(); header.setObjectName('header')
        h=W.QHBoxLayout(header); h.setContentsMargins(24,17,24,17)
        brand=W.QVBoxLayout(); name=W.QLabel('ELEVEN'); name.setObjectName('brand'); brand.addWidget(name)
        sub=W.QLabel('DESKTOP  /  MESH → DXF'); sub.setObjectName('subtitle'); brand.addWidget(sub)
        h.addLayout(brand); h.addSpacing(26)
        identity=W.QVBoxLayout()
        self.file_label=W.QLabel('مدلی باز نشده'); self.file_label.setObjectName('filename'); self.file_label.setAlignment(C.Qt.AlignRight)
        self.model_info=W.QLabel('STL  ·  OBJ  ·  PLY  ·  OFF  ·  GLB  ·  3MF'); self.model_info.setObjectName('hint')
        identity.addWidget(self.file_label); identity.addWidget(self.model_info)
        h.addLayout(identity); h.addStretch()
        self.open_btn=self.button('باز کردن مدل',self.open_model,'Ctrl+O'); h.addWidget(self.open_btn)
        self.preview_btn=self.button('پیش‌نمایش قطعات',self.preview,'F5'); h.addWidget(self.preview_btn)
        self.export_btn=self.button('ذخیره DXF',self.export_dxf,'Ctrl+E'); self.export_btn.setObjectName('primary'); h.addWidget(self.export_btn)
        outer.addWidget(header)
        split=W.QSplitter(C.Qt.Horizontal); split.setChildrenCollapsible(False)
        canvas=W.QWidget(); cv=W.QVBoxLayout(canvas); cv.setContentsMargins(18,16,12,12); cv.setSpacing(10)
        tools=W.QHBoxLayout()
        self.view_title=W.QLabel('فضای کار'); self.view_title.setObjectName('sectionTitle'); tools.addWidget(self.view_title)
        tools.addStretch()
        for title,key in [('سه‌ربع','iso'),('روبرو','front'),('بالا','top'),('کنار','side')]:
            b=self.button(title,lambda checked=False,k=key:self.current_view().preset(k)); tools.addWidget(b)
        fit=self.button('نمای کامل',lambda:self.fit_current(),'F'); tools.addWidget(fit)
        cv.addLayout(tools)
        self.tabs=W.QTabWidget()
        self.plotter=MeshView(); self.view2d=View2D(); self.plotter2=MeshView()
        self.tabs.addTab(self.plotter,'۱   مدل و صفحهٔ برش')
        self.tabs.addTab(self.view2d,'۲   چیدمان قطعات')
        self.tabs.addTab(self.plotter2,'۳   مونتاژ سه‌بعدی')
        self.tabs.currentChanged.connect(lambda:self._update_hint())
        cv.addWidget(self.tabs,1)
        self.hint=W.QLabel('کشیدن: چرخش   •   چرخ ماوس: زوم   •   Shift + کشیدن: جابه‌جایی   •   دوبار کلیک: نمای کامل')
        self.hint.setObjectName('hint'); self.hint.setAlignment(C.Qt.AlignRight); cv.addWidget(self.hint)
        self.progress=W.QProgressBar(); self.progress.setRange(0,0); self.progress.setFixedHeight(5); self.progress.hide(); cv.addWidget(self.progress)
        self.status=W.QLabel('یک مدل باز کنید یا فایل آن را داخل پنجره بکشید.'); self.status.setWordWrap(True); self.status.setAlignment(C.Qt.AlignRight)
        self.status.setMinimumHeight(42); cv.addWidget(self.status)
        split.addWidget(canvas)
        self.panel_w=W.QWidget(); self.panel_w.setObjectName('settingsPanel'); self.panel_w.setLayoutDirection(C.Qt.RightToLeft)
        panel=W.QVBoxLayout(self.panel_w); panel.setContentsMargins(16,16,16,20); panel.setSpacing(12)
        title=W.QLabel('تنظیمات ساخت'); title.setObjectName('sectionTitle'); panel.addWidget(title)
        desc=W.QLabel('اندازه، جهت و کیفیت را تنظیم کنید.'); desc.setObjectName('hint'); panel.addWidget(desc)
        g,f=self.group('ابعاد نهایی',panel)
        self.sx,self.sy,self.sz=(dspin(0.01,1e6,100) for _ in range(3))
        for label,sp in [('طول  X',self.sx),('عرض  Y',self.sy),('عمق  Z',self.sz)]:
            sp.setSuffix(' mm'); f.addRow(label,sp)
        self.lock=W.QCheckBox('حفظ تناسب ابعاد'); self.lock.setChecked(True); f.addRow(self.lock)
        for sp,ax in ((self.sx,0),(self.sy,1),(self.sz,2)):
            sp.valueChanged.connect(lambda val,a=ax:self.size_changed(a,val))
        g,f=self.group('روش ساخت و کیفیت',panel)
        self.rib_mode=W.QCheckBox('حالت دنده‌ای — عمود بر صفحهٔ پشت'); self.rib_mode.setChecked(True); f.addRow(self.rib_mode)
        self.rib_t=dspin(0.05,1000,2.6,0.1); self.rib_t.setSuffix(' mm'); f.addRow('ضخامت ورق',self.rib_t)
        self.quality=W.QComboBox()
        for text,k in [('۱  •  استاندارد',1),('۲  •  جزئیات',2),('۳  •  جزئیات بالا',3),('۴  •  اولترا — فاصله صفر',4)]: self.quality.addItem(text,k)
        self.quality.setCurrentIndex(1); f.addRow('کیفیت',self.quality)
        axisrow=W.QWidget(); al=W.QHBoxLayout(axisrow); al.setContentsMargins(0,0,0,0)
        self.rib_axis=AxisPick()
        for key in ('x','y','z'):
            rb=W.QRadioButton(key.upper()); self.rib_axis.btns[key]=rb; al.addWidget(rb); rb.clicked.connect(self.plane_changed)
        self.rib_axis.btns['x'].setChecked(True); f.addRow('محور چیدن قطعات',axisrow)
        self.rib_ang=dspin(-180,180,0,5,1); self.rib_ang.setSuffix('°'); f.addRow('چرخش راستا',self.rib_ang)
        g,f=self.group('صفحهٔ پشت و جهت',panel)
        self.back_face=W.QComboBox()
        face_titles={'ymax':'پشت: بیشینهٔ Y → جلو: −Y','ymin':'پشت: کمینهٔ Y → جلو: +Y',
                     'xmax':'پشت: بیشینهٔ X → جلو: −X','xmin':'پشت: کمینهٔ X → جلو: +X',
                     'zmax':'پشت: بیشینهٔ Z → جلو: −Z','zmin':'پشت: کمینهٔ Z → جلو: +Z',
                     'camera':'جهت انتخاب‌شده از دوربین','custom':'دلخواه — نقطه و زاویه'}
        for text,key,_ in FACES:
            self.back_face.addItem(face_titles[key],key)
            self.back_face.setItemData(self.back_face.count()-1,text,C.Qt.ToolTipRole)
        self.back_face.setMinimumContentsLength(12); self.back_face.setSizeAdjustPolicy(W.QComboBox.AdjustToMinimumContentsLengthWithIcon)
        f.addRow('وجه پشت',self.back_face)
        self.back_off=dspin(-1e5,1e5,0,1); self.back_off.setSuffix(' mm'); f.addRow('آفست صفحه به داخل',self.back_off)
        self.flip=W.QCheckBox('برعکس کردن سمت جلو'); f.addRow(self.flip)
        self.snap=W.QCheckBox('چسباندن جهت دوربین به نزدیک‌ترین محور'); self.snap.setChecked(True); f.addRow(self.snap)
        self.cam_button=self.button('انتخاب صفحهٔ پشت از نمای دوربین',self.from_camera); f.addRow(self.cam_button)
        self.dir_label=W.QLabel('—'); self.dir_label.setWordWrap(True); self.dir_label.setObjectName('hint'); f.addRow(self.dir_label)
        advanced=W.QToolButton(); advanced.setText('تنظیمات پیشرفته'); advanced.setCheckable(True); advanced.setToolButtonStyle(C.Qt.ToolButtonTextBesideIcon)
        advanced.setArrowType(C.Qt.LeftArrow); panel.addWidget(advanced)
        self.advanced=W.QWidget(); adv=W.QVBoxLayout(self.advanced); adv.setContentsMargins(0,0,0,0); adv.setSpacing(12)
        g,f=self.group('نقطه و زاویهٔ دلخواه',adv)
        self.ox,self.oy,self.oz=(dspin(-1e6,1e6,0) for _ in range(3))
        self.ang_a=dspin(-180,180,0,5,1); self.ang_b=dspin(-180,180,0,5,1)
        for label,sp in [('نقطه X',self.ox),('نقطه Y',self.oy),('نقطه Z',self.oz),('زاویه حول X',self.ang_a),('زاویه حول Y',self.ang_b)]: f.addRow(label,sp)
        pk=self.button('انتخاب نقطه روی سطح مدل',self.start_pick); f.addRow(pk)
        self.plane_ws=[self.ox,self.oy,self.oz,self.ang_a,self.ang_b,pk]
        g,f=self.group('لایه‌بندی و پاک‌سازی کانتور',adv)
        self.thick=dspin(0.01,1e4,3,0.5); self.gap=dspin(0,100,0.5,0.1)
        self.holes=W.QCheckBox('حفظ حفره‌ها در پیش‌نمایش و DXF')
        self.merge_d=dspin(0,1000,1,0.5); self.minpct=dspin(0,50,3,1,1)
        self.tol=dspin(0,1000,0.5,0.1); self.maxslab=dspin(0,10000,30,1)
        for label,sp in [('ضخامت لایه',self.thick),('بستن شکاف‌های ریز',self.gap),('فاصلهٔ ادغام جزیره‌ها',self.merge_d),('حذف جزیره‌های کوچک (%)',self.minpct),('تلرانس لایه‌های مشابه',self.tol),('حداکثر ضخامت قطعه (۰=آزاد)',self.maxslab)]: f.addRow(label,sp)
        f.addRow(self.holes)
        g,f=self.group('اتصال دنده‌ها به پشت',adv)
        self.rib_bridge=W.QCheckBox('اتصال جزیره‌ها به خط پشت'); self.rib_bridge.setChecked(False)
        self.rib_web=dspin(0,100,4,0.5); f.addRow(self.rib_bridge); f.addRow('عرض اتصال پشت',self.rib_web)
        panel.addWidget(self.advanced); self.advanced.hide()
        advanced.toggled.connect(lambda on:(self.advanced.setVisible(on),advanced.setArrowType(C.Qt.DownArrow if on else C.Qt.LeftArrow)))
        self.help_label=W.QLabel('لایه‌بندی کلاسیک: تیک حالت دنده‌ای را بردارید.\nتنظیمات پیشرفته اختیاری‌اند.'); self.help_label.setWordWrap(True); self.help_label.setObjectName('hint'); panel.addWidget(self.help_label)
        panel.addStretch()
        sc=W.QScrollArea(); sc.setWidgetResizable(True); sc.setWidget(self.panel_w); sc.setMinimumWidth(355); sc.setMaximumWidth(510)
        split.addWidget(sc); split.setSizes([1000,390]); split.setStretchFactor(0,1); split.setStretchFactor(1,0)
        outer.addWidget(split,1)
        self.statusBar().showMessage('ELEVEN Desktop 1.0  •  پردازش محلی و آفلاین')
        self._size_hint=W.QLabel('بدون VTK / بدون مرورگر'); self.statusBar().addPermanentWidget(self._size_hint)
        # Connect only after all controls exist (the inherited handlers use all of them).
        for sp in (self.ox,self.oy,self.oz,self.ang_a,self.ang_b): sp.valueChanged.connect(self.redraw)
        for signal in (self.back_face.currentIndexChanged,self.back_off.valueChanged,self.flip.stateChanged,self.rib_bridge.stateChanged): signal.connect(self.plane_changed)
        for sp in (self.rib_ang,self.rib_t):sp.valueChanged.connect(self.redraw)
        self.rib_mode.stateChanged.connect(self._mode_changed)
        self.quality.currentIndexChanged.connect(self._stale)
        for sp in (self.thick,self.gap,self.merge_d,self.minpct,self.tol,self.maxslab,self.rib_web):sp.valueChanged.connect(self._stale)
        self.holes.stateChanged.connect(self._stale)

    def button(self,text,callback,shortcut=None):
        b=W.QPushButton(text); b.clicked.connect(callback)
        if shortcut:b.setShortcut(G.QKeySequence(shortcut)); b.setToolTip(text+'  ('+shortcut+')')
        return b

    @staticmethod
    def group(title,layout):
        g=W.QGroupBox(title); f=W.QFormLayout(g); f.setSpacing(9)
        f.setFieldGrowthPolicy(W.QFormLayout.AllNonFixedFieldsGrow)
        f.setRowWrapPolicy(W.QFormLayout.WrapLongRows)
        layout.addWidget(g); return g,f

    def _build_menu(self):
        self.menuBar().setLayoutDirection(C.Qt.RightToLeft)
        menu=self.menuBar().addMenu('فایل')
        self.open_action=menu.addAction('باز کردن مدل…',self.open_model)
        self.export_action=menu.addAction('ذخیرهٔ DXF…',self.export_dxf)
        menu.addSeparator()
        self.save_action=menu.addAction('ذخیرهٔ تنظیمات…',self.save_settings)
        self.load_action=menu.addAction('بارگذاری تنظیمات…',self.load_settings)
        menu.addSeparator(); menu.addAction('خروج',self.close)
        view=self.menuBar().addMenu('نمایش')
        view.addAction('نمای کامل',self.fit_current)
        helpmenu=self.menuBar().addMenu('راهنما')
        helpmenu.addAction('روش استفاده',self.help)
        helpmenu.addAction('دربارهٔ ELEVEN',lambda:W.QMessageBox.about(self,'ELEVEN Desktop',
            'ELEVEN Desktop 1.0\nنسخهٔ سبک از برنامهٔ Mesh → DXF ارسالی شما.\nمحاسبات روی مدل کامل؛ نمایش نرم‌افزاری بدون VTK.\nپردازش محلی؛ بدون ارسال مدل به اینترنت.'))

    def help(self):
        W.QMessageBox.information(self,'راهنمای سریع',
            '۱. مدل را باز کنید یا داخل پنجره بکشید.\n۲. اندازه، وجه پشت، محور و کیفیت را انتخاب کنید.\n۳. پیش‌نمایش قطعات را بزنید؛ چیدمان و مونتاژ را بررسی کنید.\n۴. ذخیره DXF را بزنید.\n\n'
            'حالت دنده‌ای: ضخامت ورق ثابت و فاصلهٔ خودکار در ۴ سطح کیفیت.\n'
            'حالت لایه‌ای: تیک دنده‌ای را بردارید؛ تنظیمات ضخامت و ادغام در بخش پیشرفته است.\n'
            'جهت دوربین: در تب مدل بچرخانید، سپس دکمهٔ انتخاب صفحه از دوربین را بزنید.\n'
            'نقطه دلخواه: وجه «دلخواه» را انتخاب کنید، تنظیمات پیشرفته را باز کنید و روی سطح کلیک کنید.\n'
            'دایرهٔ قرمز DXF مرجع هم‌ترازی است. هندسه در لایه CUT و متن در LABEL قرار می‌گیرد.\n\n'
            'نمای سه‌بعدی مدل‌های بزرگ نمونه‌برداری می‌شود؛ هندسهٔ خروجی از مدل کامل محاسبه می‌شود.')

    def _set_ready(self,ready):
        self.preview_btn.setEnabled(ready and not self._busy)
        self.export_btn.setEnabled(ready and not self._busy)
        self.export_action.setEnabled(ready and not self._busy)

    def current_view(self):
        return self.plotter2 if self.tabs.currentIndex()==2 else self.plotter

    def fit_current(self):
        if self.tabs.currentIndex()==1:
            bounds=self.view2d.scene().itemsBoundingRect()
            if not bounds.isEmpty():self.view2d.fitInView(bounds,C.Qt.KeepAspectRatio)
        else:self.current_view().fit()

    def _update_hint(self):
        if self.tabs.currentIndex()==1:self.hint.setText('چرخ ماوس: زوم   •   کشیدن: جابه‌جایی   •   F: نمای کامل')
        else:self.hint.setText('کشیدن: چرخش   •   چرخ ماوس: زوم   •   Shift + کشیدن: جابه‌جایی   •   دوبار کلیک: نمای کامل')

    def _mode_changed(self,*_):
        self.rib_t.setEnabled(self.rib_mode.isChecked()); self.quality.setEnabled(self.rib_mode.isChecked())
        self._stale(); self.redraw()

    def _stale(self,*_):
        if self.mesh is not None:
            self._cache=None
            self.view2d.scene().clear(); self.plotter2.clear()
            self.status.setText('تنظیمات تغییر کرد؛ برای دیدن خروجی تازه «پیش‌نمایش قطعات» را بزنید.')

    def open_model(self):
        if self._busy:return
        path,_=W.QFileDialog.getOpenFileName(self,'باز کردن مدل سه‌بعدی','','3D models (*.stl *.obj *.ply *.off *.glb *.3mf)')
        if path:self.load_model(path)

    def load_model(self,path):
        if self._busy:return
        self._set_busy(True,'در حال خواندن مدل…')
        try:
            # Same cleanup, repair and centering sequence as the source upload.
            m=trimesh.load(path,force='mesh')
            if not isinstance(m,trimesh.Trimesh) or not len(m.faces):raise ValueError('فایل شامل سطح سه‌بعدی قابل پردازش نیست.')
            m.merge_vertices(); m.remove_unreferenced_vertices()
            try:
                m.update_faces(m.nondegenerate_faces()); m.update_faces(m.unique_faces())
                trimesh.repair.fix_normals(m); trimesh.repair.fill_holes(m)
            except Exception: logging.exception('Optional mesh repair')
            if not np.isfinite(m.vertices).all() or min(m.extents)<=0:raise ValueError('ابعاد مدل معتبر نیست یا یک محور اندازهٔ صفر دارد.')
            m.apply_translation(-m.bounds.mean(axis=0))
            self.base=m; self.orig=m.extents.copy(); self.model_path=str(path)
            self._lock_busy=True
            for sp,val in zip((self.sx,self.sy,self.sz),self.orig):sp.setValue(float(val))
            self._lock_busy=False
            self.apply_size()
            self.plotter.fit(); self.tabs.setCurrentIndex(0)
            self.file_label.setText(Path(path).name)
            self.model_info.setText(f'{len(m.faces):,} مثلث   •   '+ ' × '.join(f'{v:.2f}' for v in self.orig)+' mm')
            self.status.setText('مدل آماده است. اندازه و جهت را تنظیم کنید، سپس پیش‌نمایش بگیرید.')
        except Exception as exc:
            self._lock_busy=False; self.show_error('باز کردن مدل ناموفق بود',exc)
        finally:self._set_busy(False)

    def make_disp(self):
        # The original used VTK display decimation above 200k faces, then analysed
        # that decimated display for quality planning. Keep FULL mesh here.
        return SimpleNamespace(points=self.mesh.vertices)

    def analysis_mesh(self):
        return self.mesh

    def redraw(self,*_):
        if self.mesh is None:return
        self._stale()
        n,o=self.normal(),self.origin()
        self.plotter.set_mesh(self.mesh,n,o,self.rib_frame(n) if self.rib_mode.isChecked() else None)

    def start_pick(self):
        if self.mesh is None:return
        self.tabs.setCurrentIndex(0)
        def picked(pt):
            for sp,v in zip((self.ox,self.oy,self.oz),pt):
                sp.blockSignals(True); sp.setValue(float(v)); sp.blockSignals(False)
            self.plotter.disable_picking(); self.redraw(); self.status.setText('نقطهٔ صفحه روی سطح مدل انتخاب شد.')
        self.plotter.enable_surface_point_picking(picked)
        self.status.setText('روی سطح مدل کلیک کنید؛ Esc انتخاب نقطه را لغو می‌کند.')

    def draw_assembly(self,slabs):
        vertices=[]; faces=[]
        rib=self.rib_mode.isChecked() and self._frame is not None
        axis=self._frame[1] if rib else self.normal()
        for z0,z1,polys,_ in slabs:
            mid=(z0+z1)/2; half=(z1-z0)/2
            for poly in polys:
                caps=constrained_delaunay_triangles(poly)
                for tri in caps.geoms:
                    points=self.to3d(np.array(tri.exterior.coords)[:3],mid)
                    i=len(vertices); vertices.extend(points-axis*half); vertices.extend(points+axis*half)
                    faces.extend([(i,i+2,i+1),(i+3,i+4,i+5)])
                for ring in [poly.exterior]+list(poly.interiors):
                    points=self.to3d(np.array(ring.coords)[:-1],mid); count=len(points); i=len(vertices)
                    vertices.extend(points-axis*half); vertices.extend(points+axis*half)
                    for j in range(count):
                        k=(j+1)%count
                        faces.extend([(i+j,i+k,i+count+k),(i+j,i+count+k,i+count+j)])
        if faces:
            self.plotter2.set_assembly(trimesh.Trimesh(vertices=np.array(vertices),faces=np.array(faces),process=False))
        else:self.plotter2.clear()

    def _set_busy(self,busy,message=None):
        self._busy=busy
        self.open_btn.setEnabled(not busy); self.open_action.setEnabled(not busy)
        self.save_action.setEnabled(not busy); self.load_action.setEnabled(not busy)
        self.panel_w.setEnabled(not busy)
        self.progress.setVisible(busy)
        self._set_ready(self.mesh is not None)
        if message:self.status.setText(message)
        if busy:W.QApplication.processEvents()

    def preview(self):
        if self._busy or self.mesh is None:return
        self._set_busy(True,'در حال ساخت قطعات…')
        try:super().preview()
        except Exception as exc:self.show_error('ساخت پیش‌نمایش ناموفق بود',exc)
        finally:self._set_busy(False)

    def export_dxf(self):
        if self._busy or self.mesh is None:return
        self._set_busy(True,'در حال آماده‌سازی خروجی DXF…')
        try:super().export_dxf()
        except Exception as exc:self.show_error('ذخیره DXF ناموفق بود',exc)
        finally:self._set_busy(False)

    def show_error(self,title,exc):
        logging.exception(title)
        self.status.setText(title+'؛ مدل و تنظیمات قبلی حفظ شده‌اند.')
        W.QMessageBox.critical(self,title,str(exc))

    def dragEnterEvent(self,event):
        if not self._busy and event.mimeData().hasUrls():event.acceptProposedAction()

    def dropEvent(self,event):
        if not self._busy:
            urls=event.mimeData().urls()
            if urls and urls[0].isLocalFile():self.load_model(urls[0].toLocalFile())

    def keyPressEvent(self,event):
        if event.key()==C.Qt.Key_Escape:
            self.plotter.disable_picking(); self.status.setText('انتخاب نقطه لغو شد.')
        else:super().keyPressEvent(event)

    def closeEvent(self,event):
        if self._busy:
            event.ignore(); self.status.setText('پس از پایان پردازش می‌توانید پنجره را ببندید.')
        else:event.accept()

    def settings_data(self):
        fields=('sx','sy','sz','ox','oy','oz','ang_a','ang_b','thick','gap','merge_d','minpct','tol','maxslab','rib_t','rib_ang','rib_web','back_off')
        data={name:getattr(self,name).value() for name in fields}
        data.update({name:getattr(self,name).isChecked() for name in ('lock','holes','flip','snap','rib_mode','rib_bridge')})
        data.update(schema=1,quality=self.quality.currentData(),back_face=self.back_face.currentData(),rib_axis=self.rib_axis.currentData(),cam_vec=self.cam_vec)
        return data

    def save_settings(self):
        path,_=W.QFileDialog.getSaveFileName(self,'ذخیره تنظیمات','eleven-settings.json','JSON (*.json)')
        if not path:return
        try:
            Path(path).write_text(json.dumps(self.settings_data(),ensure_ascii=False,indent=2),encoding='utf-8')
            self.status.setText('تنظیمات ذخیره شد؛ فایل مدل داخل این فایل قرار نمی‌گیرد.')
        except Exception as exc:self.show_error('ذخیره تنظیمات ناموفق بود',exc)

    def load_settings(self):
        path,_=W.QFileDialog.getOpenFileName(self,'باز کردن تنظیمات','','JSON (*.json)')
        if not path:return
        try:
            data=json.loads(Path(path).read_text(encoding='utf-8'))
            self.apply_settings(data)
            self.status.setText('تنظیمات بارگذاری شد؛ دوباره پیش‌نمایش بگیرید.')
        except Exception as exc:self.show_error('بارگذاری تنظیمات ناموفق بود',exc)

    def apply_settings(self,data):
        if not isinstance(data,dict) or data.get('schema')!=1:raise ValueError('نسخه یا ساختار فایل تنظیمات معتبر نیست.')
        current=self.settings_data()
        numeric=('sx','sy','sz','ox','oy','oz','ang_a','ang_b','thick','gap','merge_d','minpct','tol','maxslab','rib_t','rib_ang','rib_web','back_off')
        checks=('lock','holes','flip','snap','rib_mode','rib_bridge')
        # Validate everything before applying any value.
        for name in numeric:
            val=data.get(name,current[name]); sp=getattr(self,name)
            if isinstance(val,bool) or not isinstance(val,(int,float)) or not np.isfinite(val) or not sp.minimum()<=val<=sp.maximum():raise ValueError('مقدار نامعتبر: '+name)
        for name in checks:
            if name in data and not isinstance(data[name],bool):raise ValueError('مقدار نامعتبر: '+name)
        if data.get('quality',current['quality']) not in (1,2,3,4):raise ValueError('کیفیت نامعتبر است.')
        if data.get('back_face',current['back_face']) not in [key for _,key,_ in FACES]:raise ValueError('وجه نامعتبر است.')
        if data.get('rib_axis',current['rib_axis']) not in ('x','y','z'):raise ValueError('محور نامعتبر است.')
        cam=data.get('cam_vec',current['cam_vec'])
        if cam is not None:
            cam=np.asarray(cam,dtype=float)
            if cam.shape!=(3,) or not np.isfinite(cam).all() or np.linalg.norm(cam)<1e-10:raise ValueError('بردار دوربین معتبر نیست.')
            cam=tuple(cam/np.linalg.norm(cam))
        widgets=[getattr(self,k) for k in numeric+checks]+[self.quality,self.back_face]+list(self.rib_axis.btns.values())
        for w in widgets:w.blockSignals(True)
        try:
            for name in numeric:getattr(self,name).setValue(data.get(name,current[name]))
            for name in checks:getattr(self,name).setChecked(data.get(name,current[name]))
            self.quality.setCurrentIndex(self.quality.findData(data.get('quality',current['quality'])))
            self.back_face.setCurrentIndex(self.back_face.findData(data.get('back_face',current['back_face'])))
            self.rib_axis.btns[data.get('rib_axis',current['rib_axis'])].setChecked(True)
            self.cam_vec=cam
            self._last_n=None
        finally:
            for w in widgets:w.blockSignals(False)
        self._mode_changed()
        if self.base is not None:self.apply_size()
        else:self.plane_changed()
        self.plotter.fit()


def main():
    W.QApplication.setAttribute(C.Qt.AA_EnableHighDpiScaling,True)
    W.QApplication.setAttribute(C.Qt.AA_UseHighDpiPixmaps,True)
    app=W.QApplication(sys.argv); app.setApplicationName('ELEVEN Desktop'); app.setOrganizationName('ELEVEN')
    app.setStyle('Fusion'); app.setFont(G.QFont('Segoe UI',10))
    logdir=Path(C.QStandardPaths.writableLocation(C.QStandardPaths.AppLocalDataLocation)); logdir.mkdir(parents=True,exist_ok=True)
    logging.basicConfig(filename=logdir/'eleven.log',level=logging.WARNING,encoding='utf-8')
    def hook(kind,value,tb):
        logging.error('Unhandled error',exc_info=(kind,value,tb))
        W.QMessageBox.critical(None,'ELEVEN — خطا',str(value))
    sys.excepthook=hook
    window=Desktop(); window.show()
    if len(sys.argv)>1 and Path(sys.argv[1]).is_file():C.QTimer.singleShot(0,lambda:window.load_model(sys.argv[1]))
    return app.exec_()


if __name__=='__main__':sys.exit(main())
