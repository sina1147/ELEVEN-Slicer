"""Small native Qt software viewport. Rendering never changes analysis geometry."""
import math
import numpy as np
from PyQt5 import QtCore as C, QtGui as G, QtWidgets as W


class MeshView(W.QWidget):
    picked = C.pyqtSignal(object)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(360, 320)
        self.setMouseTracking(True)
        self.setFocusPolicy(C.Qt.StrongFocus)
        self.yaw, self.pitch = -0.75, 0.5
        self.zoom = 1.0
        self.pan = np.zeros(2)
        self.center = np.zeros(3)
        self.radius = 60.0
        self.mesh = None
        self.triangles = np.empty((0, 3, 3))
        self.colors = np.empty((0, 4))
        self.lines = []
        self._last = None
        self._moved = False
        self._pick = None
        self._screen = None

    def basis(self):
        cy, sy = math.cos(self.yaw), math.sin(self.yaw)
        cp, sp = math.cos(self.pitch), math.sin(self.pitch)
        right = np.array([cy, sy, 0.0])
        up = np.array([-sy * sp, cy * sp, cp])
        toward = np.cross(right, up)
        return np.array([right, up, toward])

    @property
    def camera_position(self):
        return (self.center + self.basis()[2] * self.radius * 3,
                self.center.copy(), self.basis()[1])

    def scale_factor(self):
        return min(self.width(), self.height()) * 0.40 / max(self.radius, 1e-9) * self.zoom

    def project(self, points):
        q = (np.asarray(points) - self.center) @ self.basis().T
        xy = q[..., :2] * np.array([1, -1]) * self.scale_factor()
        xy += np.array([self.width() / 2, self.height() / 2]) + self.pan
        return xy, q[..., 2]

    def fit(self):
        if self.mesh is not None:
            self.center = self.mesh.bounds.mean(axis=0)
            self.radius = float(max(self.mesh.extents.max(), 1e-6)) * 0.65
        self.zoom = 1.0
        self.pan[:] = 0
        self._screen = None
        self.update()

    def preset(self, name):
        self.yaw, self.pitch = {'iso': (-0.75, 0.5), 'front': (0, 0),
                                'top': (0, math.pi / 2), 'side': (math.pi / 2, 0)}[name]
        self._screen = None
        self.update()

    @staticmethod
    def sample(mesh, limit=6500):
        if len(mesh.faces) <= limit:
            return np.asarray(mesh.triangles)
        # Only the viewport is sampled; all vertices/faces remain in self.mesh.
        ix = np.linspace(0, len(mesh.faces) - 1, limit, dtype=int)
        return np.asarray(mesh.vertices)[np.asarray(mesh.faces)[ix]]

    def set_mesh(self, mesh, normal=None, origin=None, ribs=None, fit=False):
        self.mesh = mesh
        self.lines = []
        if mesh is None:
            self.clear()
            return
        triangles = self.sample(mesh)
        self.triangles = triangles
        self.colors = np.tile([91, 168, 224, 255], (len(triangles), 1))
        if normal is not None:
            # Clip sampled display triangles exactly at the selected plane.
            distances = (triangles - origin) @ normal
            front, back = [], []
            for tri, ds in zip(triangles, distances):
                if ds.min() >= 0:
                    front.append(tri)
                elif ds.max() <= 0:
                    back.append(tri)
                else:
                    back.append(tri)
                    poly = []
                    for i in range(3):
                        a, b, da, db = tri[i-1], tri[i], ds[i-1], ds[i]
                        if (da >= 0) != (db >= 0):
                            poly.append(a + (b-a) * (da / (da-db)))
                        if db >= 0:
                            poly.append(b)
                    for i in range(1, len(poly)-1):
                        front.append([poly[0], poly[i], poly[i+1]])
            self.triangles = np.asarray(back + front, dtype=float).reshape(-1, 3, 3)
            self.colors = np.array([[105, 123, 144, 38]] * len(back) +
                                   [[91, 168, 224, 255]] * len(front), dtype=float).reshape(-1, 4)
            n = np.asarray(normal)
            axis = np.eye(3)[int(np.argmin(np.abs(n)))]
            u = np.cross(n, axis); u /= np.linalg.norm(u)
            v = np.cross(n, u)
            s = float(mesh.extents.max()) * 0.65
            corners = np.array([origin + s*(a*u+b*v) for a,b in ((-1,-1),(1,-1),(1,1),(-1,1),(-1,-1))])
            self.lines.append((corners, '#f2b66a', 1.8))
            self.lines.append((np.array([origin, origin+n*s*0.6]), '#ff806e', 2.5))
            if ribs is not None:
                ru, rv = ribs
                self.lines.append((np.array([origin, origin+ru*s*0.6]), '#72d6b0', 2.5))
                vv = mesh.vertices-origin
                good = (vv @ n) >= 0
                if good.any():
                    lo, hi = float((vv[good] @ ru).min()), float((vv[good] @ ru).max())
                    for d in np.linspace(lo, hi, 9)[1:-1]:
                        c = origin+ru*d
                        pts = np.array([c-s*rv, c+s*rv, c+s*rv+n*s, c-s*rv+n*s, c-s*rv])
                        self.lines.append((pts, '#315b59', 0.8))
        if fit:
            self.fit()
        self._screen = None
        self.update()

    def set_assembly(self, mesh, fit=True):
        self.set_mesh(mesh, fit=fit)

    def clear(self):
        self.mesh = None
        self.triangles = np.empty((0,3,3))
        self.lines = []
        self._screen = None
        self.update()

    def add_axes(self):
        self.update()

    def reset_camera(self):
        self.fit()

    def disable_picking(self):
        self._pick = None
        self.unsetCursor()

    def enable_surface_point_picking(self, callback, **kwargs):
        self._pick = callback
        self.setCursor(C.Qt.CrossCursor)

    def pick_surface(self, pos):
        if self.mesh is None:
            return None
        b = self.basis()
        xy = (np.array([pos.x(),pos.y()]) - np.array([self.width()/2,self.height()/2])-self.pan) / self.scale_factor()
        start = self.center+b[0]*xy[0]-b[1]*xy[1]+b[2]*self.radius*4
        direction = -b[2]
        # Orthographic ray/triangle test against the ORIGINAL full-resolution mesh.
        ts = self.mesh.triangles
        e1, e2 = ts[:,1]-ts[:,0], ts[:,2]-ts[:,0]
        h = np.cross(np.broadcast_to(direction,e2.shape),e2)
        det = np.einsum('ij,ij->i',e1,h)
        ok = np.abs(det)>1e-12
        f = np.zeros_like(det); f[ok] = 1/det[ok]
        s = start-ts[:,0]
        u = f*np.einsum('ij,ij->i',s,h)
        q = np.cross(s,e1)
        v = f*(q@direction)
        t = f*np.einsum('ij,ij->i',e2,q)
        ok &= (u>=0)&(v>=0)&(u+v<=1)&(t>=0)
        if not ok.any():
            return None
        return start+direction*float(t[np.flatnonzero(ok)[np.argmin(t[ok])]])

    def paintEvent(self, event):
        p = G.QPainter(self)
        p.setRenderHint(G.QPainter.Antialiasing)
        p.fillRect(self.rect(), G.QColor('#111923'))
        p.setPen(G.QPen(G.QColor('#1a2633'),1))
        for x in range(0,self.width(),36): p.drawLine(x,0,x,self.height())
        for y in range(0,self.height(),36): p.drawLine(0,y,self.width(),y)
        if self.mesh is None:
            p.setPen(G.QColor('#4cc7b0'))
            f=p.font(); f.setPointSize(28); f.setBold(True); p.setFont(f)
            p.drawText(self.rect().adjusted(0,-45,0,-45),C.Qt.AlignCenter,'ELEVEN')
            p.setPen(G.QColor('#91a1b5')); f.setPointSize(12); f.setBold(False); p.setFont(f)
            p.drawText(self.rect().adjusted(0,45,0,45),C.Qt.AlignCenter,'برای شروع، یک مدل سه‌بعدی باز کنید')
        elif len(self.triangles):
            if self._screen is None:
                xy, depth = self.project(self.triangles)
                ns = np.cross(self.triangles[:,1]-self.triangles[:,0],self.triangles[:,2]-self.triangles[:,0])
                ns /= np.maximum(np.linalg.norm(ns,axis=1)[:,None],1e-12)
                light = np.clip(np.abs(ns @ np.array([0.25,-0.4,0.88])),0,1)*0.45+0.55
                colors=self.colors.astype(float); colors[:,:3] *= light[:,None]
                order=np.argsort(depth.mean(axis=1))
                self._screen=[(G.QPolygonF([C.QPointF(float(x),float(y)) for x,y in xy[i]]),G.QColor(*[int(c) for c in colors[i]])) for i in order]
            p.setPen(C.Qt.NoPen)
            for poly,color in self._screen:
                p.setBrush(color); p.drawPolygon(poly)
        for points,color,width in self.lines:
            xy,_ = self.project(points)
            p.setPen(G.QPen(G.QColor(color),width)); p.setBrush(C.Qt.NoBrush)
            p.drawPolyline(G.QPolygonF([C.QPointF(float(x),float(y)) for x,y in xy]))
        if self.mesh is not None:
            base=np.array([52,self.height()-48])
            for i,(color,label) in enumerate((('#ff877a','X'),('#71d6ab','Y'),('#76adf7','Z'))):
                d=self.basis()[:2,i]*np.array([1,-1])*30
                p.setPen(G.QPen(G.QColor(color),2)); p.drawLine(C.QPointF(*base),C.QPointF(*(base+d)))
                p.drawText(C.QPointF(*(base+d*1.25)),label)
        p.end()

    def resizeEvent(self,event):
        self._screen=None
        super().resizeEvent(event)

    def mousePressEvent(self,event):
        self._last=event.pos(); self._moved=False

    def mouseMoveEvent(self,event):
        if self._last is None or not event.buttons(): return
        d=event.pos()-self._last
        self._moved |= d.manhattanLength()>2
        if event.buttons() & C.Qt.LeftButton and not event.modifiers() & C.Qt.ShiftModifier:
            self.yaw += d.x()*0.008
            self.pitch = max(-math.pi/2,min(math.pi/2,self.pitch+d.y()*0.008))
        else:
            self.pan += [d.x(),d.y()]
        self._last=event.pos(); self._screen=None; self.update()

    def mouseReleaseEvent(self,event):
        if self._pick and not self._moved and event.button()==C.Qt.LeftButton:
            pt=self.pick_surface(event.pos())
            if pt is not None: self._pick(pt)
        self._last=None

    def wheelEvent(self,event):
        self.zoom = max(0.05,min(50,self.zoom*1.15**(event.angleDelta().y()/120)))
        self._screen=None; self.update()

    def mouseDoubleClickEvent(self,event):
        self.fit()
