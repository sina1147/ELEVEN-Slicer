"""Mesh -> DXF layer slicer.
نصب:  pip install numpy trimesh shapely ezdxf pyvista pyvistaqt PyQt5
اجرا:  python mesh2dxf.py
"""
import sys
import numpy as np
import trimesh
import ezdxf
from shapely.geometry import Polygon
from shapely.ops import unary_union
from PyQt5 import QtWidgets as W
from PyQt5.QtCore import Qt, QPointF
from PyQt5.QtGui import QPainterPath, QPen, QColor, QBrush, QPolygonF


# جهت‌های آماده: (متن، بردار از پشت به سمت داخل مدل)
FACES = [
    ("وجه پشت = Y بالا (Y max)  ← جلو رو به Y−", "ymax", (0, -1, 0)),
    ("وجه پشت = Y پایین (Y min) ← جلو رو به Y+", "ymin", (0, 1, 0)),
    ("وجه پشت = X راست (X max)  ← جلو رو به X−", "xmax", (-1, 0, 0)),
    ("وجه پشت = X چپ (X min)    ← جلو رو به X+", "xmin", (1, 0, 0)),
    ("وجه پشت = Z بالا (Z max)  ← جلو رو به Z−", "zmax", (0, 0, -1)),
    ("وجه پشت = Z پایین (Z min) ← جلو رو به Z+", "zmin", (0, 0, 1)),
    ("از روی دوربین (دکمه زیر)", "camera", None),
    ("دلخواه (نقطه + زاویه)", "custom", None),
]
FACE_VEC = {k: np.array(v, float) for _, k, v in FACES if v is not None}


class AxisPick:
    """سه دکمه‌ی رادیویی X/Y/Z؛ currentData() = محور انتخاب‌شده"""
    def __init__(self):
        self.btns = {}

    def currentData(self):
        for k, b in self.btns.items():
            if b.isChecked():
                return k
        return "x"


def dspin(lo, hi, val, step=1.0, dec=2):
    s = W.QDoubleSpinBox()
    s.setRange(lo, hi); s.setValue(val); s.setSingleStep(step); s.setDecimals(dec)
    return s


class App(W.QMainWindow):

    # ---------- مدل ----------
    def open_model(self):
        path, _ = W.QFileDialog.getOpenFileName(self, "مدل", "", "3D (*.stl *.obj *.ply *.off *.glb *.3mf)")
        if not path:
            return
        m = trimesh.load(path, force="mesh")
        m.merge_vertices(); m.remove_unreferenced_vertices()
        try:
            m.update_faces(m.nondegenerate_faces()); m.update_faces(m.unique_faces())
            trimesh.repair.fix_normals(m); trimesh.repair.fill_holes(m)
        except Exception:
            pass
        m.apply_translation(-m.bounds.mean(axis=0))
        self.base = m
        self.orig = m.extents.copy()
        self._lock_busy = True
        for s, v in zip((self.sx, self.sy, self.sz), self.orig):
            s.setValue(float(v))
        self._lock_busy = False
        self.apply_size()

    def size_changed(self, ax, v):
        if self.base is None or self._lock_busy:
            return
        self._lock_busy = True
        if self.lock.isChecked():
            k = v / self.orig[ax]
            for i, s in enumerate((self.sx, self.sy, self.sz)):
                if i != ax:
                    s.setValue(float(self.orig[i] * k))
        self._lock_busy = False
        self.apply_size()

    def apply_size(self):
        tgt = np.array([self.sx.value(), self.sy.value(), self.sz.value()])
        self.mesh = self.base.copy()
        self.mesh.apply_scale(tgt / self.orig)
        self.pm_disp = self.make_disp()
        self.plane_changed()

    # ---------- صفحه ----------
    def is_custom(self):
        return self.back_face.currentData() == "custom"

    def normal(self):
        key = self.back_face.currentData()
        if key in FACE_VEC:
            n = FACE_VEC[key].copy()
        elif key == "camera" and self.cam_vec is not None:
            n = np.array(self.cam_vec, float)
        else:
            a, b = np.radians(self.ang_a.value()), np.radians(self.ang_b.value())
            n = np.array([np.cos(a) * np.sin(b), -np.sin(a), np.cos(a) * np.cos(b)])
        return -n if self.flip.isChecked() else n

    def origin(self):
        return np.array([self.ox.value(), self.oy.value(), self.oz.value()])

    def plane_changed(self, *_):
        """وقتی جهت آماده انتخاب شود، نقطه صفحه خودکار روی لبه‌ی پشت مدل (+ جابه‌جایی) می‌نشیند."""
        custom = self.is_custom()
        if custom and getattr(self, "_last_n", None) is not None:
            # ورود به حالت دلخواه: زاویه‌ها را از جهت فعلی بساز تا صفحه از همان‌جا شروع شود
            nn = -self._last_n if self.flip.isChecked() else self._last_n
            ta = -np.degrees(np.arcsin(np.clip(nn[1], -1, 1)))
            tb = np.degrees(np.arctan2(nn[0], nn[2]))
            for sp, val in ((self.ang_a, ta), (self.ang_b, tb)):
                sp.blockSignals(True); sp.setValue(float(val)); sp.blockSignals(False)
            self._last_n = None
        for w in self.plane_ws:
            w.setEnabled(custom)
        if self.mesh is not None and not custom:
            n = self.normal()
            P = (self.pm_disp.points if self.pm_disp is not None else self.mesh.vertices)
            c0 = self.mesh.bounds.mean(axis=0)
            dmin = float(((P - c0) @ n).min())
            o = c0 + n * (dmin + self.back_off.value())
            for sp, val in zip((self.ox, self.oy, self.oz), o):
                sp.blockSignals(True); sp.setValue(float(val)); sp.blockSignals(False)
        if not custom:
            self._last_n = self.normal()
        if self.mesh is not None:
            n = self.normal(); u, _v = self.rib_frame(n)
            nm = lambda x: "(" + ", ".join(f"{t:+.2f}" for t in x) + ")"
            self.dir_label.setText(f"سمت جلو (از پشت به داخل): {nm(n)}\nراستای چیدن قطعات: {nm(u)}"
                                   + (f"\n⚠ {self.rib_note}" if self.rib_note else ""))
            self.view2d.scene().clear(); self.plotter2.clear(); self._cache = None
            self.status.setText("جهت تغییر کرد؛ دوباره «پیش‌نمایش قطعات» را بزن.")
        self.redraw()

    def from_camera(self):
        """سطحی که دوربین نگاهش می‌کند = صفحه پشت؛ مدل پشت آن (از دید بیننده) قرار می‌گیرد."""
        if self.mesh is None:
            return
        pos, foc, _up = self.plotter.camera_position
        d = np.array(foc, float) - np.array(pos, float)
        d /= np.linalg.norm(d)
        if self.snap.isChecked():
            i = int(np.argmax(np.abs(d)))
            d = np.zeros(3); d[i] = np.sign(self.plotter.camera_position[1][i] - self.plotter.camera_position[0][i])
        self.cam_vec = tuple(float(x) for x in d)
        self.back_face.blockSignals(True)
        self.back_face.setCurrentIndex(self.back_face.findData("camera"))
        self.back_face.blockSignals(False)
        self.plane_changed()
        self.status.setText("جهت از روی دوربین تنظیم شد: " + ", ".join(f"{x:.2f}" for x in d))

    def rib_frame(self, n):
        """بردار راستای دنده‌ها u و v = n×u ؛ اگر محور انتخابی موازی n باشد، خودکار عوض می‌شود."""
        key = self.rib_axis.currentData()
        E = {"x": np.array([1.0, 0, 0]), "y": np.array([0, 1.0, 0]), "z": np.array([0, 0, 1.0])}
        self.rib_note = ""
        if key in E:
            e = E[key]
            if abs(e @ n) > 0.9:
                for alt in ("x", "z", "y"):
                    if abs(E[alt] @ n) < 0.9:
                        self.rib_note = f"محور {key.upper()} موازی جهت برش است؛ محور {alt.upper()} استفاده شد"
                        e = E[alt]; break
        else:
            e = np.array([1.0, 0, 0]) if abs(n[0]) < 0.9 else np.array([0, 1.0, 0])
        u = e - (e @ n) * n; u /= np.linalg.norm(u)
        if abs(self.rib_ang.value()) > 1e-9:
            th = np.radians(self.rib_ang.value())
            u = u * np.cos(th) + np.cross(n, u) * np.sin(th)
        return u, np.cross(n, u)



    # ---------- برش‌ها ----------
    def layer_polys(self, po, n, eps):
        """مقطع -> چندضلعی‌های بسته. از پاره‌خط‌های خام مقطع استفاده می‌کند،
        پس روی مدل‌های سوراخ‌دار/خراب هم کار می‌کند."""
        from shapely.geometry import MultiLineString
        segs = trimesh.intersections.mesh_plane(self.mesh, n, po)
        if segs is None or len(segs) == 0:
            return []
        T = trimesh.geometry.plane_transform(po, n)   # مبدأ و جهت ثابت بین لایه‌ها
        pts = trimesh.transformations.transform_points(np.asarray(segs).reshape(-1, 3), T)
        xy = pts[:, :2].reshape(-1, 2, 2)
        e = max(eps, 1e-4 * float(self.mesh.extents.max()))
        u = MultiLineString([s for s in xy]).buffer(e, resolution=4).buffer(0)
        geoms = list(u.geoms) if hasattr(u, "geoms") else [u]
        out = []
        for g in geoms:
            if not isinstance(g, Polygon) or g.is_empty:
                continue
            g = g if self.holes.isChecked() else Polygon(g.exterior)
            g = g.buffer(-e)                 # برگرداندن به اندازه واقعی
            out += list(g.geoms) if hasattr(g, "geoms") else [g]
        out = [g for g in out if isinstance(g, Polygon) and not g.is_empty]
        if not self.holes.isChecked() and out:
            u2 = unary_union(out)
            out = list(u2.geoms) if hasattr(u2, "geoms") else [u2]
        return out

    def compute_layers(self):
        n, o = self.normal(), self.origin()
        dmax = float(((self.mesh.vertices - o) @ n).max())
        t, eps = self.thick.value(), self.gap.value()
        if dmax / t > 2000:
            raise ValueError(f"تعداد لایه‌ها خیلی زیاد می‌شود ({int(dmax / t)}). ضخامت را بیشتر کن.")
        layers, h = [], t / 2
        while h < dmax:
            try:
                gs = self.layer_polys(o + n * h, n, eps)
            except Exception as ex:
                print("layer skipped at", h, ex)
                gs = []
            if gs:
                layers.append((h, gs))
            h += t
        return layers

    def clean_layer(self, gs):
        """ادغام جزیره‌های نزدیک + حذف جزیره‌های ریز (بزرگ‌ترین قطعه همیشه می‌ماند)"""
        u = unary_union(gs)
        d = self.merge_d.value()
        if d > 0:
            u = u.buffer(d).buffer(-d)
        geoms = list(u.geoms) if hasattr(u, "geoms") else [u]
        geoms = [g for g in geoms if isinstance(g, Polygon) and not g.is_empty]
        if not geoms:
            return []
        if not self.holes.isChecked():
            geoms = [Polygon(g.exterior) for g in geoms]
        big = max(g.area for g in geoms)
        return [g for g in geoms if g.area >= big * self.minpct.value() / 100.0]

    def merge_layers(self, layers, t):
        """لایه‌های پشت‌سرهمی که فرمشان در حد تلرانس یکی است -> یک قطعه ضخیم‌تر.
        خروجی: [(z0, z1, polys, تعداد لایه)]"""
        tol, maxth = self.tol.value(), self.maxslab.value()
        groups, cur = [], [layers[0]]
        for L in layers[1:]:
            ok = False
            if tol > 0:
                ref, cand = unary_union(cur[0][1]), unary_union(L[1])
                thick = (len(cur) + 1) * t
                consecutive = abs(L[0] - cur[-1][0] - t) < 1e-6
                ok = (consecutive and (maxth <= 0 or thick <= maxth + 1e-9)
                      and ref.buffer(tol).contains(cand) and cand.buffer(tol).contains(ref))
            if ok:
                cur.append(L)
            else:
                groups.append(cur); cur = [L]
        groups.append(cur)
        out = []
        for gr in groups:
            rep = gr[len(gr) // 2]                       # نماینده: لایه وسط
            out.append((gr[0][0] - t / 2, gr[-1][0] + t / 2, rep[1], len(gr)))
        return out

    def fill_section(self, mesh, u, v, n, o, sv, e):
        """مقطع پرشده‌ی جلوی صفحه پشت در مختصات (v, n) ؛ shapely یا None"""
        from shapely.geometry import MultiLineString, box
        segs = trimesh.intersections.mesh_plane(mesh, u, o + u * sv)
        if segs is None or len(segs) == 0:
            return None
        P = np.asarray(segs).reshape(-1, 3) - o
        xy = np.stack([P @ v, P @ n], axis=1).reshape(-1, 2, 2)
        m = MultiLineString([q for q in xy]).buffer(e, resolution=4).buffer(0)
        gl = list(m.geoms) if hasattr(m, "geoms") else [m]
        fill = []
        for g in gl:
            if isinstance(g, Polygon) and not g.is_empty:
                g = g if self.holes.isChecked() else Polygon(g.exterior)
                g = g.buffer(-e)
                fill += list(g.geoms) if hasattr(g, "geoms") else [g]
        fill = [g for g in fill if isinstance(g, Polygon) and not g.is_empty]
        if not fill:
            return None
        return unary_union(fill).intersection(box(-1e7, 0, 1e7, 1e7))   # فقط جلوی صفحه


    def plan_ribs(self, u, v, n, o, umin, umax, t):
        """تعداد و فاصله‌ی قطعات از هندسه‌ی واقعی؛ فاصله همیشه یکنواخت.
        سطح ۴: ورق‌ها پشت‌سرهم بدون فاصله (ضخامت واقعی ورق تغییر نمی‌کند، اختلاف ابعاد گزارش می‌شود).
        سطح ۱ تا ۳: n = max(n_شکل، n_حجم) با سقف ظرفیت:
          n_شکل = ceil(تغییر کل شکل مقاطع ÷ تغییر مجاز بین دو دنده‌ی مجاور)
          n_حجم = ceil(طول ÷ (ضریب × اندازه‌ی مشخصه‌ی مقطع))  ← «تکرار ضروری»: ناحیه‌ی بدون تغییر هم پوشش حجمی می‌خواهد
        هیچ مقطعی فقط به‌خاطر شبیه بودن به همسایه حذف نمی‌شود."""
        L = umax - umin
        nmax = max(1, int(L / t + 1e-9))
        level = self.quality.currentData()
        if level == 4:
            mism = L - nmax * t
            st = umin + mism / 2
            pos = [st + (k + 0.5) * t for k in range(nmax)]
            return pos, t, f"سطح ۴: {nmax} ورق پشت‌سرهم (فاصله ۰)؛ اختلاف با طول مدل: {mism:.3f} (ضخامت ورق تغییر نکرد)"
        am = self.analysis_mesh()
        e = max(self.gap.value(), 1e-3 * float(self.mesh.extents.max()))
        M = int(min(nmax, 90)); M = max(M, min(nmax, 12))
        sp = [umin + (k + 0.5) * L / M for k in range(M)]
        shapes = []
        for sv in sp:
            try:
                shapes.append(self.fill_section(am, u, v, n, o, sv, e))
            except Exception:
                shapes.append(None)
            W.QApplication.processEvents()
        A = [g.area if g is not None else 0.0 for g in shapes]
        nz = [a for a in A if a > 0]
        R = float(np.sqrt(np.mean(nz))) if nz else 1.0
        d = []
        for g1, g2, a1, a2 in zip(shapes[:-1], shapes[1:], A[:-1], A[1:]):
            m = max(a1, a2)
            if m <= 0:
                d.append(0.0); continue
            try:
                a_ = g1 if g1 is not None else Polygon()
                b_ = g2 if g2 is not None else Polygon()
                d.append(min(2.0, a_.symmetric_difference(b_).area / m))
            except Exception:
                d.append(0.0)
        TV = float(sum(d))
        static = sum(1 for x in d if x < 0.005)
        TAU = {1: 0.30, 2: 0.15, 3: 0.07}
        RP = {1: 0.40, 2: 0.22, 3: 0.12}
        CAP = {1: 0.30, 2: 0.55, 3: 0.80}
        ns, prev = {}, 0
        for lv in (1, 2, 3):
            raw = max(int(np.ceil(TV / TAU[lv])), int(np.ceil(L / (RP[lv] * R))), 3)
            cap = max(1, min(nmax - 1, int(CAP[lv] * nmax)))
            val = min(raw, cap)
            if prev:
                val = max(val, int(np.ceil(prev * 1.25)))
            val = min(val, max(1, nmax - 1))
            ns[lv] = val; prev = val
        cnt = ns[level]
        pitch = L / cnt
        pos = [umin + (k + 0.5) * pitch for k in range(cnt)]
        rep = (f"سطح {level}: {cnt} قطعه از ظرفیت {nmax} | فاصله یکنواخت {pitch - t:.2f} | "
               f"تغییر کل شکل {TV:.2f} | مقاطع مشابه نگه‌داشته‌شده (تکرار ضروری): {static} از {len(d)} | "
               f"تعدادها (۱/۲/۳): {ns[1]}/{ns[2]}/{ns[3]}")
        return pos, pitch, rep

    def rib_parts(self):
        """هر قطعه = مقطع عمود بر صفحه پشت؛ تعداد/فاصله از plan_ribs (سطح کیفیت)"""
        from shapely.geometry import box
        n, o = self.normal(), self.origin()
        u, v = self.rib_frame(n)
        self._frame = (o, u, v, n)
        V = self.mesh.vertices - o
        front = (V @ n) >= 0
        if not front.any():
            return []
        us = V[front] @ u
        umin, umax = float(us.min()), float(us.max())
        t = self.rib_t.value()
        pos, pitch, self.rib_report = self.plan_ribs(u, v, n, o, umin, umax, t)
        e = max(self.gap.value(), 1e-4 * float(self.mesh.extents.max()))
        web = self.rib_web.value()
        bridge = self.rib_bridge.isChecked()
        parts = []
        for sv in pos:
            u_ = self.fill_section(self.mesh, u, v, n, o, sv, e)
            if u_ is None or u_.is_empty:
                continue
            gs = list(u_.geoms) if hasattr(u_, "geoms") else [u_]
            gs = self.clean_layer([g for g in gs if isinstance(g, Polygon) and not g.is_empty])
            if not gs:
                continue
            out = []
            for g in gs:                       # جزیره‌ی معلق -> فقط اگر اتصال روشن باشد تا خط پشت پر شود
                g = g.simplify(0.02)
                if bridge and g.bounds[1] > 1e-3:
                    r = list(g.exterior.coords)
                    quads = [Polygon([a, b, (b[0], 0), (a[0], 0)]) for a, b in zip(r[:-1], r[1:])
                             if abs(a[0] - b[0]) > 1e-9]
                    g = unary_union([g] + [q.buffer(0) for q in quads])
                out.append(g)
            u2 = unary_union(out)
            out = list(u2.geoms) if hasattr(u2, "geoms") else [u2]
            if bridge and len(out) > 1 and web > 0:
                x0 = min(g.bounds[0] for g in out); x1 = max(g.bounds[2] for g in out)
                u3 = unary_union(out + [box(x0, 0, x1, web)])
                out = list(u3.geoms) if hasattr(u3, "geoms") else [u3]
            out = [g for g in out if isinstance(g, Polygon) and not g.is_empty]
            parts.append((sv - t / 2, sv + t / 2, out, 1))
            W.QApplication.processEvents()
        self.rib_info = (len(pos), pitch - t)
        return parts


    def sig(self):
        ws = [self.sx, self.sy, self.sz, self.ox, self.oy, self.oz, self.ang_a, self.ang_b,
              self.thick, self.gap, self.merge_d, self.minpct, self.tol, self.maxslab,
              self.rib_t, self.rib_ang, self.rib_web, self.back_off]
        return (id(self.mesh), self.quality.currentData(), self.rib_bridge.isChecked(), self.back_face.currentData(), self.rib_axis.currentData(),
                self.back_off.value(), tuple(self.cam_vec or ()), self.flip.isChecked(), self.holes.isChecked(),
                self.rib_mode.isChecked(), tuple(round(w.value(), 6) for w in ws))

    def build_slabs(self):
        """محاسبه قطعات (با کش: پیش‌نمایش و خروجی یک بار محاسبه می‌شوند)"""
        if self.mesh is None:
            self.status.setText("اول مدل را باز کن."); return None
        sg = self.sig()
        if self._cache and self._cache[0] == sg:
            return self._cache[1]
        self.panel_w.setEnabled(False); self.progress.show()
        self.status.setText("در حال محاسبه... (برای مدل‌های سنگین کمی طول می‌کشد)")
        W.QApplication.processEvents()
        try:
            if self.rib_mode.isChecked():
                slabs = self.rib_parts()
                nb = na = sum(len(sl[2]) for sl in slabs); nl = len(slabs)
            else:
                raw = self.compute_layers()
                layers = [(h, self.clean_layer(gs)) for h, gs in raw]
                layers = [(h, gs) for h, gs in layers if gs]
                slabs = self.merge_layers(layers, self.thick.value()) if layers else []
                nb = sum(len(gs) for _, gs in raw); na = sum(len(sl[2]) for sl in slabs); nl = len(layers)
        finally:
            self.panel_w.setEnabled(True); self.progress.hide()
        res = (slabs, nb, na, nl)
        self._cache = (sg, res)
        return res

    def arrange(self, slabs):
        """چیدمان قطعات کنار هم (مشترک بین پیش‌نمایش و DXF) -> [(dx, dy, x, y)]"""
        sizes = [unary_union(sl[2]).bounds for sl in slabs]
        row_w = max(1000.0, max(b[2] - b[0] for b in sizes) * 3)
        gap, x, y, rowh, out = 10.0, 0.0, 0.0, 0.0, []
        for b in sizes:
            w, hh = b[2] - b[0], b[3] - b[1]
            if x > 0 and x + w > row_w:
                x, y, rowh = 0.0, y - rowh - gap - 8, 0.0
            out.append((x - b[0], y - b[3], x, y))
            x += w + gap; rowh = max(rowh, hh)
        return out

    def label(self, i, sl):
        return f"P{i + 1}  z={sl[0]:.1f}..{sl[1]:.1f}  th={sl[1] - sl[0]:.1f}"

    def preview(self):
        r = self.build_slabs()
        if r is None:
            return
        slabs, nb, na, nl = r
        if not slabs:
            self.status.setText("چیزی جلوی صفحه نیست."); return
        place = self.arrange(slabs)
        self.view2d.show_parts(slabs, place, self.holes.isChecked(),
                               [self.label(i, sl) for i, sl in enumerate(slabs)])
        self.draw_assembly(slabs)
        self.tabs.setCurrentIndex(1)
        extra = ""
        if self.rib_mode.isChecked() and hasattr(self, "rib_info"):
            extra = " | " + getattr(self, "rib_report", "")
            if getattr(self, "rib_note", ""):
                extra += " | " + self.rib_note
        self.status.setText(f"{nl} لایه/مقطع -> {len(slabs)} قطعه ({nb} -> {na} تکه‌ی بسته){extra}")

    def to3d(self, xy, zmid):
        xy = np.asarray(xy)
        if self.rib_mode.isChecked() and self._frame is not None:
            o, u, v, n = self._frame      # x=a (راستای v)، y=w (راستای n)، zmid روی u
            return o + np.outer(xy[:, 0], v) + np.outer(xy[:, 1], n) + zmid * u
        o, n = self.origin(), self.normal()
        T = trimesh.geometry.plane_transform(o, n)
        inv = np.linalg.inv(T)
        P = np.column_stack([xy, np.full(len(xy), zmid), np.ones(len(xy))])
        return (P @ inv.T)[:, :3]


    def export_dxf(self):
        r = self.build_slabs()
        if r is None:
            return
        slabs, nb, na, nl = r
        if not slabs:
            self.status.setText("چیزی جلوی صفحه نیست."); return
        path, _ = W.QFileDialog.getSaveFileName(self, "ذخیره", "layers.dxf", "DXF (*.dxf)")
        if not path:
            return
        doc = ezdxf.new("R2010"); msp = doc.modelspace()
        doc.layers.add("CUT", color=7); doc.layers.add("LABEL", color=3); doc.layers.add("REG", color=1)
        for i, (sl, (dx, dy, x, y)) in enumerate(zip(slabs, self.arrange(slabs))):
            for g in sl[2]:
                rings = [g.exterior] + (list(g.interiors) if self.holes.isChecked() else [])
                for rg in rings:
                    pts = [(px + dx, py + dy) for px, py in list(rg.coords)[:-1]]
                    msp.add_lwpolyline(pts, close=True, dxfattribs={"layer": "CUT"})
            msp.add_circle((dx, dy), 1.5, dxfattribs={"layer": "REG"})   # نقطه مرجع هم‌ترازی
            msp.add_text(self.label(i, sl), dxfattribs={"layer": "LABEL", "height": 3}
                         ).set_placement((x, y + 3))
        doc.saveas(path)
        self.status.setText(f"{len(slabs)} قطعه ذخیره شد.\nدایره قرمز = نقطه مرجع؛ قطعات را روی آن هم‌تراز کنید.")


class View2D(W.QGraphicsView):
    """پیش‌نمایش دوبعدی قطعات؛ چرخ ماوس = زوم، کشیدن = جابه‌جایی"""
    def __init__(self):
        super().__init__(W.QGraphicsScene())
        self.setRenderHint(0x01)
        self.setDragMode(W.QGraphicsView.ScrollHandDrag)
        self.setBackgroundBrush(QBrush(QColor("#1e2228")))

    def wheelEvent(self, ev):
        k = 1.2 if ev.angleDelta().y() > 0 else 1 / 1.2
        self.scale(k, k)

    def show_parts(self, slabs, place, holes, labels):
        sc = self.scene(); sc.clear()
        pen = QPen(QColor("#ff5c5c")); pen.setCosmetic(True); pen.setWidthF(1.2)
        fill = QBrush(QColor(255, 92, 92, 40))
        for sl, (dx, dy, x, y), lb in zip(slabs, place, labels):
            path = QPainterPath(); path.setFillRule(Qt.OddEvenFill)
            for g in sl[2]:
                rings = [g.exterior] + (list(g.interiors) if holes else [])
                for rg in rings:
                    poly = QPolygonF([QPointF(px + dx, -(py + dy)) for px, py in rg.coords])
                    path.addPolygon(poly); path.closeSubpath()
            sc.addPath(path, pen, fill)
            t = sc.addText(lb); t.setDefaultTextColor(QColor("#7ddc7d")); t.setScale(0.25)
            t.setPos(x, -(y + 6))
        self.setSceneRect(sc.itemsBoundingRect().adjusted(-20, -20, 20, 20))
        self.fitInView(sc.itemsBoundingRect(), Qt.KeepAspectRatio)

def _hook(et, ev, tb):
    import traceback
    msg = "".join(traceback.format_exception(et, ev, tb))
    print(msg)
    W.QMessageBox.critical(None, "خطا", msg[-1500:])


