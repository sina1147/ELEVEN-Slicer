@echo off
setlocal
cd /d "%~dp0"
title ELEVEN Desktop - Diagnostics
echo Starting the bundled runtime. No installation or download is performed.
"%~dp0runtime\python.exe" -I "%~dp0bootstrap.py"
set "ELEVEN_STATUS=%ERRORLEVEL%"
echo.
echo Exit status: %ELEVEN_STATUS%
if not "%ELEVEN_STATUS%"=="0" echo Please send the error text above for help.
pause
exit /b %ELEVEN_STATUS%
