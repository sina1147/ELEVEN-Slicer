"""Entry point shared by the portable launcher and console diagnostics."""
import os
import sys
from pathlib import Path

root=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'app'))
os.environ.pop('QT_PLUGIN_PATH',None)
os.environ.pop('QT_QPA_PLATFORM_PLUGIN_PATH',None)
os.environ.setdefault('QT_AUTO_SCREEN_SCALE_FACTOR','1')

try:
    from main import main
    raise SystemExit(main())
except Exception:
    import traceback
    text=traceback.format_exc()
    print(text,file=sys.stderr)
    try:
        import ctypes
        ctypes.windll.user32.MessageBoxW(None,text[-2400:],'ELEVEN startup error',0x10)
    except Exception:
        pass
    raise
