@echo off
setlocal
cd /d "%~dp0"
set "ELEVEN_GRAPHICS=opengl"
set "QT_OPENGL="
"%~dp0runtime\pythonw.exe" -I "%~dp0bootstrap.py"
