/* Driver-independent indexed triangle rasterizer. No mesh decimation. */
#include <stdint.h>
#include <math.h>
#ifdef _WIN32
#define EXPORT __declspec(dllexport)
#else
#define EXPORT __attribute__((visibility("default")))
#endif

static float edge(float ax,float ay,float bx,float by,float x,float y) {
    return (x-ax)*(by-ay)-(y-ay)*(bx-ax);
}

EXPORT void rasterize(int vertices,int triangles,int width,int height,
 const float *positions,const float *colors,const uint32_t *faces,
 uint8_t *image,float *depth) {
    for(int i=0;i<triangles;i++) {
        uint32_t ia=faces[3*i],ib=faces[3*i+1],ic=faces[3*i+2];
        if(ia>=(uint32_t)vertices || ib>=(uint32_t)vertices || ic>=(uint32_t)vertices)continue;
        const float *a=positions+3*ia,*b=positions+3*ib,*c=positions+3*ic;
        float area=edge(a[0],a[1],b[0],b[1],c[0],c[1]);
        if(!isfinite(area) || fabsf(area)<1e-10f)continue;
        float loX=fminf(a[0],fminf(b[0],c[0])),hiX=fmaxf(a[0],fmaxf(b[0],c[0]));
        float loY=fminf(a[1],fminf(b[1],c[1])),hiY=fmaxf(a[1],fmaxf(b[1],c[1]));
        if(hiX<0 || hiY<0 || loX>=width || loY>=height)continue;
        int x0=(int)fmaxf(0,floorf(loX)),x1=(int)fminf(width-1,ceilf(hiX));
        int y0=(int)fmaxf(0,floorf(loY)),y1=(int)fminf(height-1,ceilf(hiY));
        float inv=1.0f/area;
        const float *ca=colors+3*ia,*cb=colors+3*ib,*cc=colors+3*ic;
        for(int y=y0;y<=y1;y++)for(int x=x0;x<=x1;x++) {
            float px=x+0.5f,py=y+0.5f;
            float wa=edge(b[0],b[1],c[0],c[1],px,py)*inv;
            float wb=edge(c[0],c[1],a[0],a[1],px,py)*inv;
            float wc=1.0f-wa-wb;
            if(wa<-.00001f || wb<-.00001f || wc<-.00001f)continue;
            float z=wa*a[2]+wb*b[2]+wc*c[2];
            int index=y*width+x;
            if(z<=depth[index])continue;
            depth[index]=z;
            uint8_t *p=image+4*index;
            for(int k=0;k<3;k++) {
                float value=wa*ca[k]+wb*cb[k]+wc*cc[k];
                p[k]=(uint8_t)fminf(255,fmaxf(0,value));
            }
            p[3]=255;
        }
    }
}
