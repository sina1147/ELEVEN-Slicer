import os

# The safe default never creates a QOpenGLWidget, probes a driver or loads Mesa.
if os.environ.get('ELEVEN_GRAPHICS','cpu').lower()=='opengl':
    from gpu_view import MeshView,configure_graphics
else:
    from cpu_view import MeshView
    def configure_graphics():pass
