"""Opaque, smooth, depth-buffered surfaces without an OpenGL context or driver."""
import ctypes
import logging
import sys
from pathlib import Path
import numpy as np
from PyQt5 import QtCore as C,QtGui as G,QtWidgets as W
from gpu_view import MeshView as GLView

class MeshView(W.QWidget):
    picked=C.pyqtSignal(object)
    backend_name='CPU rasterizer (no OpenGL)'
    basis=GLView.basis
    camera_position=GLView.camera_position
    scale_factor=GLView.scale_factor
    project=GLView.project
    fit=GLView.fit
    preset=GLView.preset
    pick_surface=GLView.pick_surface
    disable_picking=GLView.disable_picking
    enable_surface_point_picking=GLView.enable_surface_point_picking
    mousePressEvent=GLView.mousePressEvent
    mouseMoveEvent=GLView.mouseMoveEvent
    mouseReleaseEvent=GLView.mouseReleaseEvent
    mouseDoubleClickEvent=GLView.mouseDoubleClickEvent
    wheelEvent=GLView.wheelEvent
    reset_camera=GLView.reset_camera
    add_axes=GLView.add_axes
    set_mesh=GLView.set_mesh
    set_assembly=GLView.set_assembly
    clear=GLView.clear
    displayed_face_count=GLView.displayed_face_count
    displayed_vertices=GLView.displayed_vertices

    def __init__(self,parent=None):
        super().__init__(parent);self.setMinimumSize(360,320)
        self.setMouseTracking(True);self.setFocusPolicy(C.Qt.StrongFocus)
        self.yaw,self.pitch=-.75,.5;self.zoom=1.;self.pan=np.zeros(2);self.center=np.zeros(3);self.radius=60.
        self.mesh=None;self.lines=[];self._pick=None;self._last=None;self._moved=False;self._screen=None
        self._plane=None;self._origin=np.zeros(3);self._vertices=None;self._indices=None;self._dirty=False
        self._source_mesh=None;self._scale=np.ones(3);self._count=0
        self._image=None;self._pixels=None;self._native=None;self._error=None
        try:
            library=Path(__file__).with_name('cpu_raster.dll' if sys.platform=='win32' else 'cpu_raster.so')
            self._native=ctypes.CDLL(str(library))
            fp=ctypes.POINTER(ctypes.c_float)
            self._native.rasterize.argtypes=[ctypes.c_int]*4+[fp,fp,ctypes.POINTER(ctypes.c_uint32),ctypes.POINTER(ctypes.c_uint8),fp]
            self._native.rasterize.restype=None
        except Exception as exc:
            self._error=str(exc);logging.exception('CPU rasterizer initialization')

    def update(self,*args):
        self._image=None
        super().update(*args)

    def isValid(self):return self._native is not None
    def _cleanup(self):pass

    def _render(self):
        if self.mesh is None or not self._native or not self._count:return
        # A bounded image resolution reduces pixel cost, without dropping faces.
        factor=min(1.,1000/max(1,self.width()),800/max(1,self.height()))
        width=max(1,int(self.width()*factor));height=max(1,int(self.height()*factor))
        world=self.displayed_vertices
        xy,z=self.project(world)
        xy*=np.array([width/max(1,self.width()),height/max(1,self.height())])
        positions=np.ascontiguousarray(np.column_stack([xy,z]),dtype=np.float32)
        normals=(self._vertices[:,3:]/self._scale)@self.basis().T
        normals/=np.maximum(np.linalg.norm(normals,axis=1)[:,None],1e-12)
        normals[normals[:,2]<0]*=-1
        light=np.array([-.35,.5,.85]);light/=np.linalg.norm(light)
        diffuse=np.maximum(normals@light,0)
        half=light+np.array([0,0,1.]);half/=np.linalg.norm(half)
        spec=np.maximum(normals@half,0)**36*.18
        base=np.tile([.40,.69,.85],(len(world),1))
        if self._plane is not None:
            rear=(world-self._origin)@self._plane<-.0001
            base[rear]=base[rear]*.4+np.array([.47,.52,.59])*.6
        colors=np.ascontiguousarray((base*(.38+.62*diffuse[:,None])+spec[:,None])*255,dtype=np.float32)
        self._pixels=np.empty((height,width,4),dtype=np.uint8);self._pixels[:]=[17,25,35,255]
        depth=np.full((height,width),-np.inf,dtype=np.float32)
        ptr=lambda a:a.ctypes.data_as(ctypes.POINTER(ctypes.c_float))
        self._native.rasterize(len(world),self.displayed_face_count,width,height,ptr(positions),ptr(colors),
            self._indices.ctypes.data_as(ctypes.POINTER(ctypes.c_uint32)),
            self._pixels.ctypes.data_as(ctypes.POINTER(ctypes.c_uint8)),ptr(depth))
        self._image=G.QImage(self._pixels.data,width,height,width*4,G.QImage.Format_RGBA8888).copy()
        self._dirty=False

    def grabFramebuffer(self):
        if self._image is None:self._render()
        return self._image.copy() if self._image is not None else self.grab().toImage()

    def resizeEvent(self,event):
        self._image=None;super().resizeEvent(event)

    def paintEvent(self,event):
        if self._image is None:
            try:self._render()
            except Exception as exc:self._error=str(exc);logging.exception('CPU surface render')
        p=G.QPainter(self);p.setRenderHint(G.QPainter.Antialiasing);p.fillRect(self.rect(),G.QColor('#111923'))
        if self._image is not None:
            p.setRenderHint(G.QPainter.SmoothPixmapTransform);p.drawImage(self.rect(),self._image)
        if self.mesh is None or self._error:
            p.setPen(G.QColor('#64d7bb'));f=p.font();f.setPointSize(28);f.setBold(True);p.setFont(f)
            p.drawText(self.rect().adjusted(0,-30,0,-30),C.Qt.AlignCenter,'ELEVEN')
            f.setPointSize(11);f.setBold(False);p.setFont(f);p.setPen(G.QColor('#9badc0'))
            text=('خطای نمایش: '+self._error) if self._error else 'برای شروع، یک مدل سه‌بعدی باز کنید'
            p.drawText(self.rect().adjusted(30,40,-30,-10),C.Qt.AlignCenter|C.Qt.TextWordWrap,text)
        for points,color,width in self.lines:
            xy,_=self.project(points);p.setPen(G.QPen(G.QColor(color),width));p.setBrush(C.Qt.NoBrush)
            p.drawPolyline(G.QPolygonF([C.QPointF(float(x),float(y)) for x,y in xy]))
        if self.mesh is not None:
            base=np.array([52,self.height()-48])
            for i,(color,label) in enumerate((('#ff877a','X'),('#71d6ab','Y'),('#76adf7','Z'))):
                d=self.basis()[:2,i]*np.array([1,-1])*30;p.setPen(G.QPen(G.QColor(color),2))
                p.drawLine(C.QPointF(*base),C.QPointF(*(base+d)));p.drawText(C.QPointF(*(base+d*1.25)),label)
        p.end()
