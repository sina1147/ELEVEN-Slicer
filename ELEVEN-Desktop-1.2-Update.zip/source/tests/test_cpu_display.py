"""Safe startup and depth ordering must work without creating an OpenGL widget."""
import os
import sys
import ctypes
import unittest
from pathlib import Path
import numpy as np
from PyQt5 import QtCore as C,QtGui as G,QtWidgets as W
ROOT=Path(__file__).resolve().parents[1]
APP_ROOT=ROOT if (ROOT/'app').exists() else ROOT.parent
sys.path.insert(0,str(APP_ROOT/'app'))
from cpu_view import MeshView
from main import Desktop

class CPUDisplay(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.app=W.QApplication.instance() or W.QApplication([])

    def test_default_window_draws_without_opengl(self):
        if os.environ.get('ELEVEN_GRAPHICS')=='opengl':self.skipTest('Explicit optional GPU mode')
        w=Desktop();w.show();self.app.processEvents()
        try:
            self.assertNotIsInstance(w.plotter,W.QOpenGLWidget)
            self.assertNotIsInstance(w.plotter2,W.QOpenGLWidget)
            self.assertIsNone(G.QOpenGLContext.currentContext())
            self.assertIsNone(w.plotter._error)
            im=w.grab().toImage().convertToFormat(G.QImage.Format_RGBA8888)
            data=im.bits();data.setsize(im.byteCount())
            pixels=np.frombuffer(data,dtype=np.uint8).reshape(im.height(),im.bytesPerLine()//4,4)
            # The full window is painted, including controls, before loading a mesh.
            self.assertGreater(float(np.mean(pixels[:,:,:3].mean(axis=2)<180)),.85)
            self.assertTrue(w.open_btn.isVisible())
        finally:
            w.close();w.deleteLater();self.app.sendPostedEvents(None,C.QEvent.DeferredDelete)

    def test_depth_buffer_is_independent_of_face_order(self):
        view=MeshView();self.assertIsNone(view._error)
        try:
            points=np.array([[2,2,0],[18,2,0],[2,18,0],[2,2,1],[18,2,1],[2,18,1]],dtype=np.float32)
            colors=np.array([[0,0,255]]*3+[[255,0,0]]*3,dtype=np.float32)
            ptr=lambda a:a.ctypes.data_as(ctypes.POINTER(ctypes.c_float))
            for order in ([0,1,2,3,4,5],[3,4,5,0,1,2]):
                faces=np.array(order,dtype=np.uint32);image=np.zeros((20,20,4),dtype=np.uint8);depth=np.full((20,20),-np.inf,dtype=np.float32)
                view._native.rasterize(6,2,20,20,ptr(points),ptr(colors),faces.ctypes.data_as(ctypes.POINTER(ctypes.c_uint32)),image.ctypes.data_as(ctypes.POINTER(ctypes.c_uint8)),ptr(depth))
                np.testing.assert_array_equal(image[5,5],[255,0,0,255])
        finally:view.close()

if __name__=='__main__':unittest.main(verbosity=2)
