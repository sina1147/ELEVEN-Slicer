"""Regression: dense meshes must remain continuous, and resizing must update live."""
import os
import sys
import tempfile
import time
import unittest
from pathlib import Path
import numpy as np
import trimesh
from PyQt5 import QtCore as C, QtGui as G, QtWidgets as W

ROOT=Path(__file__).resolve().parents[1]
APP_ROOT=ROOT if (ROOT/'app').exists() else ROOT.parent
sys.path.insert(0,str(APP_ROOT/'app'))
from viewer import MeshView,configure_graphics
from main import Desktop

@unittest.skipIf(os.environ.get('ELEVEN_GRAPHICS')=='opengl' and not (os.environ.get('DISPLAY') or sys.platform=='win32'),'OpenGL tests require a display')
class Viewport(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        configure_graphics();cls.app=W.QApplication.instance() or W.QApplication([])

    @staticmethod
    def pixels(image):
        image=image.convertToFormat(G.QImage.Format_RGBA8888)
        data=image.bits();data.setsize(image.byteCount())
        return np.frombuffer(data,dtype=np.uint8).reshape(image.height(),image.bytesPerLine()//4,4)[:,:image.width()].copy()

    def test_dense_surface_has_no_sampling_holes(self):
        view=MeshView();view.resize(720,560);view.show();self.app.processEvents()
        try:
            mesh=trimesh.creation.icosphere(subdivisions=6,radius=40)
            start=time.perf_counter();view.set_mesh(mesh,fit=True);self.app.processEvents()
            pixels=self.pixels(view.grabFramebuffer())
            self.assertTrue(view.isValid());self.assertIsNone(view._error)
            self.assertEqual(view.displayed_face_count,len(mesh.faces))
            np.testing.assert_array_equal(view._indices.reshape(-1,3),mesh.faces)
            h,w=pixels.shape[:2];yy,xx=np.ogrid[:h,:w]
            radius=40*view.scale_factor()*view.devicePixelRatioF()*.85
            interior=(xx-w/2)**2+(yy-h/2)**2<radius**2
            # A complete opaque sphere has no background-colored holes inside.
            self.assertGreater(float(np.mean(pixels[:,:,:3][interior].sum(axis=1)>150)),.999)
            before=view._vertices
            view.yaw+=.8;view.update();self.app.processEvents();view.grabFramebuffer()
            self.assertIs(view._vertices,before);self.assertFalse(view._dirty)
            print('Full surface:',len(mesh.faces),'faces; first upload+frame seconds:',round(time.perf_counter()-start,3))
        finally:view.close();view.deleteLater();self.app.sendPostedEvents(None,C.QEvent.DeferredDelete);self.app.processEvents()

    def test_dimensions_change_display_without_preview(self):
        window=Desktop();window.show();self.app.processEvents()
        window.show_error=lambda title,exc:(_ for _ in ()).throw(exc)
        try:
            with tempfile.TemporaryDirectory() as td:
                path=Path(td)/'sphere.stl';trimesh.creation.icosphere(subdivisions=3,radius=25).export(path)
                window.load_model(str(path))
            window.lock.setChecked(False)
            a=self.pixels(window.plotter.grabFramebuffer().scaled(720,560))
            old=window.plotter._vertices
            window.sx.setValue(80);window.sy.setValue(30);self.app.processEvents()
            b=self.pixels(window.plotter.grabFramebuffer().scaled(720,560))
            np.testing.assert_allclose(np.ptp(window.plotter.displayed_vertices,axis=0),[80,30,50],rtol=1e-5)
            self.assertIs(window.plotter._vertices,old) # resize reuses the GPU geometry
            self.assertGreater(float(np.mean(np.any(a!=b,axis=2))),.02)
            self.assertIsNone(window._cache) # no preview/slicing operation was needed
            self.assertEqual(window.plotter.displayed_face_count,len(window.mesh.faces))
            np.testing.assert_allclose(window.plotter.mesh.extents,[80,30,50],rtol=1e-5)
        finally:window.close();window.deleteLater();self.app.sendPostedEvents(None,C.QEvent.DeferredDelete);self.app.processEvents()

if __name__=='__main__':unittest.main(verbosity=2)
